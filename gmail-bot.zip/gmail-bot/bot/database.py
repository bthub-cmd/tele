"""
Setup database SQLite: koneksi dan schema.

Menggunakan sqlite3 bawaan Python (bukan ORM) agar dependency minimal,
sesuai kebutuhan skala kecil (<2000 email/hari).

WAL mode diaktifkan untuk concurrency yang lebih baik (walau dengan 1
admin, ini tetap membantu saat user submit bersamaan).
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from typing import Iterator

from bot.config import DB_PATH

SCHEMA_SQL = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_user_id    INTEGER NOT NULL UNIQUE,
    username            TEXT,
    created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS batches (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_code              TEXT NOT NULL UNIQUE,
    batch_name              TEXT NOT NULL,
    deposit_date            TEXT NOT NULL,
    estimated_report_date   TEXT NOT NULL,
    status                  TEXT NOT NULL DEFAULT 'DRAFT',
    created_by              INTEGER NOT NULL,
    opened_at               TEXT,
    locked_at               TEXT,
    report_ready_at         TEXT,
    purged_at               TEXT,
    created_at              TEXT NOT NULL DEFAULT (datetime('now')),
    -- Metadata ringan yang dipertahankan setelah purge (§22).
    purged_total_user       INTEGER,
    purged_total_gmail      INTEGER
);

CREATE TABLE IF NOT EXISTS submissions (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    submission_code     TEXT NOT NULL UNIQUE,
    batch_id            INTEGER NOT NULL REFERENCES batches(id),
    user_id             INTEGER NOT NULL REFERENCES users(id),
    submitted_at        TEXT NOT NULL DEFAULT (datetime('now')),
    total_input         INTEGER NOT NULL DEFAULT 0,
    total_saved          INTEGER NOT NULL DEFAULT 0,
    total_duplicate      INTEGER NOT NULL DEFAULT 0,
    total_invalid_format INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS emails (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    submission_id   INTEGER NOT NULL REFERENCES submissions(id),
    batch_id        INTEGER NOT NULL REFERENCES batches(id),
    user_id         INTEGER NOT NULL REFERENCES users(id),
    email           TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'PENDING',  -- PENDING | VALID | INVALID
    submitted_at    TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(batch_id, email)
);

CREATE INDEX IF NOT EXISTS idx_emails_email ON emails(email);
CREATE INDEX IF NOT EXISTS idx_emails_batch_user ON emails(batch_id, user_id);
CREATE INDEX IF NOT EXISTS idx_emails_status ON emails(batch_id, status);

CREATE TABLE IF NOT EXISTS confirmations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id        INTEGER NOT NULL REFERENCES batches(id),
    user_id         INTEGER NOT NULL REFERENCES users(id),
    confirmed_at    TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(batch_id, user_id)
);

-- Menyimpan state percakapan sederhana per user (pengganti in-memory
-- state agar tahan restart bot).
CREATE TABLE IF NOT EXISTS user_states (
    telegram_user_id    INTEGER PRIMARY KEY,
    state               TEXT NOT NULL,
    context_json        TEXT,
    updated_at          TEXT NOT NULL DEFAULT (datetime('now'))
);
"""


def get_connection() -> sqlite3.Connection:
    """Buat koneksi baru ke database dengan pengaturan yang aman."""
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA busy_timeout = 30000;")
    return conn


def init_db() -> None:
    """Inisialisasi schema database. Aman dipanggil berkali-kali (idempotent)."""
    conn = get_connection()
    try:
        conn.executescript(SCHEMA_SQL)
        conn.commit()
    finally:
        conn.close()


@contextmanager
def db_cursor() -> Iterator[sqlite3.Cursor]:
    """Context manager: buka koneksi, commit di akhir, tutup, rollback jika error."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
