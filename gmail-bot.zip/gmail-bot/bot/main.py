"""
Entry point bot Telegram Gmail Validation.

Menjalankan:
    python -m bot.main

Pastikan environment variable BOT_TOKEN dan ADMIN_IDS sudah di-set
(lihat README.md untuk detail).
"""

from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from bot.config import BOT_TOKEN, validate_config
from bot.database import init_db
from bot.handlers import admin as admin_h
from bot.handlers import common as common_h
from bot.handlers import user as user_h
from bot.states import (
    ADMIN_INPUT_DEPOSIT_DATE,
    ADMIN_INPUT_ESTIMATED_REPORT,
    ADMIN_WAITING_INVALID_LIST,
    USER_WAITING_GMAIL_LIST,
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


async def route_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Router tunggal untuk pesan teks bebas (bukan command), diarahkan
    berdasarkan state percakapan user saat ini.

    Menggunakan satu router terpusat (bukan banyak MessageHandler terpisah)
    supaya urutan pengecekan state jelas dan tidak ada handler yang saling
    menimpa untuk update yang sama.
    """
    from bot import models

    tg_user = update.effective_user
    if tg_user is None or update.message is None:
        return

    state, _ctx = models.get_user_state(tg_user.id)

    if state == USER_WAITING_GMAIL_LIST:
        await user_h.handle_gmail_list_text(update, context)
    elif state == ADMIN_INPUT_DEPOSIT_DATE:
        await admin_h.handle_deposit_date_text(update, context)
    elif state == ADMIN_INPUT_ESTIMATED_REPORT:
        await admin_h.handle_estimated_report_text(update, context)
    elif state == ADMIN_WAITING_INVALID_LIST:
        await admin_h.handle_invalid_list_text(update, context)
    # Jika state IDLE atau lainnya: abaikan teks bebas (user diharapkan
    # memakai tombol menu).


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.error("Terjadi error saat memproses update: %s", context.error, exc_info=context.error)


def build_application() -> Application:
    app = Application.builder().token(BOT_TOKEN).build()

    # ── Commands ─────────────────────────────────────────────────────
    app.add_handler(CommandHandler("start", common_h.cmd_start))
    app.add_handler(CommandHandler("admin", common_h.cmd_admin))
    app.add_handler(CommandHandler("cancel", common_h.cmd_cancel))

    # ── Callback queries: generic ────────────────────────────────────
    app.add_handler(CallbackQueryHandler(common_h.cb_cancel, pattern=r"^cancel$"))

    # ── Callback queries: user ────────────────────────────────────────
    app.add_handler(CallbackQueryHandler(user_h.cb_user_deposit, pattern=r"^user:deposit$"))
    app.add_handler(CallbackQueryHandler(user_h.cb_user_select_batch, pattern=r"^user:selectbatch:\d+$"))
    app.add_handler(CallbackQueryHandler(user_h.cb_user_check, pattern=r"^user:check$"))
    app.add_handler(CallbackQueryHandler(user_h.cb_user_check_batch, pattern=r"^user:checkbatch:\d+$"))
    app.add_handler(CallbackQueryHandler(user_h.cb_user_confirm, pattern=r"^user:confirm:\d+$"))
    app.add_handler(CallbackQueryHandler(user_h.cb_user_mybatches, pattern=r"^user:mybatches$"))

    # ── Callback queries: admin ──────────────────────────────────────
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_open, pattern=r"^admin:open$"))
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_confirm_open, pattern=r"^admin:confirmopen:\d+$"))
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_cancel_open, pattern=r"^admin:cancelopen:\d+$"))

    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_lock, pattern=r"^admin:lock$"))
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_do_lock, pattern=r"^admin:doLock:\d+$"))

    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_list, pattern=r"^admin:list$"))

    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_invalid, pattern=r"^admin:invalid$"))
    app.add_handler(
        CallbackQueryHandler(admin_h.cb_admin_select_invalid_batch, pattern=r"^admin:selectinvalidbatch:\d+$")
    )

    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_confirmstatus, pattern=r"^admin:confirmstatus$"))
    app.add_handler(
        CallbackQueryHandler(admin_h.cb_admin_view_confirm_status, pattern=r"^admin:viewconfirmstatus:\d+$")
    )

    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_stats, pattern=r"^admin:stats$"))
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_view_stats, pattern=r"^admin:viewstats:\d+$"))

    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_export, pattern=r"^admin:export$"))
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_export_scope, pattern=r"^admin:exportscope:(batch|user)$"))
    app.add_handler(
        CallbackQueryHandler(admin_h.cb_admin_export_batch_selected, pattern=r"^admin:exportbatchsel:\d+$")
    )
    app.add_handler(
        CallbackQueryHandler(
            admin_h.cb_admin_export_user_batch_selected, pattern=r"^admin:exportuserbatchsel:\d+$"
        )
    )
    app.add_handler(
        CallbackQueryHandler(admin_h.cb_admin_select_user_for_export, pattern=r"^admin:selectuser:\d+:\d+$")
    )
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_export_batch_txt, pattern=r"^admin:exportbatchtxt:\d+$"))
    app.add_handler(
        CallbackQueryHandler(admin_h.cb_admin_export_batch_xlsx, pattern=r"^admin:exportbatchxlsx:\d+$")
    )
    app.add_handler(
        CallbackQueryHandler(admin_h.cb_admin_export_user_txt, pattern=r"^admin:exportusertxt:\d+:\d+$")
    )
    app.add_handler(
        CallbackQueryHandler(admin_h.cb_admin_export_user_xlsx, pattern=r"^admin:exportuserxlsx:\d+:\d+$")
    )

    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_purge, pattern=r"^admin:purge$"))
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_select_purge, pattern=r"^admin:selectpurge:\d+$"))
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_do_purge, pattern=r"^admin:doPurge:\d+$"))
    app.add_handler(CallbackQueryHandler(admin_h.cb_admin_force_purge, pattern=r"^admin:forcepurge:\d+$"))

    # ── Free-text router (harus didaftar terakhir agar tidak menimpa command) ──
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, route_text_message))

    app.add_error_handler(error_handler)

    return app


def main() -> None:
    validate_config()
    init_db()
    app = build_application()
    logger.info("Bot mulai berjalan (polling)...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
