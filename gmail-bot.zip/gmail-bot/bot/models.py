"""
Data access layer.

Semua interaksi dengan database (query, insert, update) dilewatkan lewat
fungsi-fungsi di sini, supaya handlers/*.py tidak berisi SQL mentah dan
logika bisnis inti (duplicate checking, matching, dsb) terpusat & mudah
diuji.

Konvensi:
    - Semua fungsi menerima/mengembalikan tipe Python biasa (dict, list,
      dataclass), bukan sqlite3.Row langsung, supaya layer di atasnya tidak
      bergantung pada detail SQLite.
    - Fungsi yang melakukan multi-step write dibungkus dalam satu
      transaction (db_cursor context manager) supaya atomic.
"""

from __future__ import annotations

import json
import secrets
import string
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from bot.database import db_cursor
from bot.states import (
    BATCH_DRAFT,
    BATCH_LOCKED,
    BATCH_OPEN,
    BATCH_PURGED,
    BATCH_REPORT_READY,
    EMAIL_INVALID,
    EMAIL_PENDING,
    EMAIL_VALID,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _gen_code(prefix: str, length: int = 6) -> str:
    """Generate kode acak (untuk submission_code) — bukan sequential agar
    tidak predictable, tapi tetap pendek dan mudah dibaca di export."""
    alphabet = string.ascii_uppercase + string.digits
    suffix = "".join(secrets.choice(alphabet) for _ in range(length))
    return f"{prefix}-{suffix}"


# ═══════════════════════════════════════════════════════════════════════
# USERS
# ═══════════════════════════════════════════════════════════════════════

def get_or_create_user(telegram_user_id: int, username: Optional[str]) -> int:
    """Ambil id internal user, buat baru kalau belum ada. Update username
    kalau berubah (user bisa ganti username Telegram kapan saja)."""
    with db_cursor() as cur:
        cur.execute(
            "SELECT id, username FROM users WHERE telegram_user_id = ?",
            (telegram_user_id,),
        )
        row = cur.fetchone()
        if row is None:
            cur.execute(
                "INSERT INTO users (telegram_user_id, username) VALUES (?, ?)",
                (telegram_user_id, username),
            )
            return cur.lastrowid
        if username and row["username"] != username:
            cur.execute(
                "UPDATE users SET username = ? WHERE id = ?",
                (username, row["id"]),
            )
        return row["id"]


def get_username_map(user_ids: list[int]) -> dict[int, str]:
    """Ambil mapping {user.id: display_name} untuk sekumpulan internal user id."""
    if not user_ids:
        return {}
    placeholders = ",".join("?" for _ in user_ids)
    with db_cursor() as cur:
        cur.execute(
            f"SELECT id, username, telegram_user_id FROM users WHERE id IN ({placeholders})",
            user_ids,
        )
        rows = cur.fetchall()
    result = {}
    for r in rows:
        label = f"@{r['username']}" if r["username"] else f"id:{r['telegram_user_id']}"
        result[r["id"]] = label
    return result


# ═══════════════════════════════════════════════════════════════════════
# USER STATE (conversation state machine, persisted)
# ═══════════════════════════════════════════════════════════════════════

def set_user_state(telegram_user_id: int, state: str, context: Optional[dict] = None) -> None:
    context_json = json.dumps(context) if context is not None else None
    with db_cursor() as cur:
        cur.execute(
            """
            INSERT INTO user_states (telegram_user_id, state, context_json, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET
                state = excluded.state,
                context_json = excluded.context_json,
                updated_at = excluded.updated_at
            """,
            (telegram_user_id, state, context_json, _now_iso()),
        )


def get_user_state(telegram_user_id: int) -> tuple[str, dict]:
    with db_cursor() as cur:
        cur.execute(
            "SELECT state, context_json FROM user_states WHERE telegram_user_id = ?",
            (telegram_user_id,),
        )
        row = cur.fetchone()
    if row is None:
        return "USER_IDLE", {}
    context = json.loads(row["context_json"]) if row["context_json"] else {}
    return row["state"], context


def clear_user_state(telegram_user_id: int, idle_state: str) -> None:
    set_user_state(telegram_user_id, idle_state, {})


# ═══════════════════════════════════════════════════════════════════════
# BATCHES
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class Batch:
    id: int
    batch_code: str
    batch_name: str
    deposit_date: str
    estimated_report_date: str
    status: str
    created_by: int
    opened_at: Optional[str]
    locked_at: Optional[str]
    report_ready_at: Optional[str]
    purged_at: Optional[str]
    purged_total_user: Optional[int]
    purged_total_gmail: Optional[int]

    @property
    def display_name(self) -> str:
        """Nama yang ditampilkan ke admin/user. batch_code TIDAK PERNAH
        ditampilkan di UI — hanya dipakai sebagai internal identifier."""
        return self.batch_name

    @classmethod
    def from_row(cls, row) -> "Batch":
        return cls(
            id=row["id"],
            batch_code=row["batch_code"],
            batch_name=row["batch_name"],
            deposit_date=row["deposit_date"],
            estimated_report_date=row["estimated_report_date"],
            status=row["status"],
            created_by=row["created_by"],
            opened_at=row["opened_at"],
            locked_at=row["locked_at"],
            report_ready_at=row["report_ready_at"],
            purged_at=row["purged_at"],
            purged_total_user=row["purged_total_user"],
            purged_total_gmail=row["purged_total_gmail"],
        )


def _next_batch_code() -> str:
    """Generate BATCH-NNN berikutnya secara sequential (BATCH-001, 002, ...).

    Sesuai Rule 1: 1x /open = 1 batch, dengan ID unik dan BUKAN berbasis
    tanggal. batch_code ini murni internal identifier — TIDAK PERNAH
    ditampilkan ke admin/user (lihat Batch.display_name).
    """
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) AS cnt FROM batches")
        cnt = cur.fetchone()["cnt"]
    return f"BATCH-{cnt + 1:03d}"


def _unique_display_name(desired_name: str) -> str:
    """Kalau ada batch aktif lain dengan nama yang sama persis, tambahkan
    penomoran '(2)', '(3)', dst supaya tetap bisa dibedakan admin tanpa
    perlu menampilkan batch_code."""
    with db_cursor() as cur:
        cur.execute(
            "SELECT batch_name FROM batches WHERE status != ?", (BATCH_PURGED,)
        )
        existing_names = {r["batch_name"] for r in cur.fetchall()}

    if desired_name not in existing_names:
        return desired_name

    n = 2
    while f"{desired_name} ({n})" in existing_names:
        n += 1
    return f"{desired_name} ({n})"


def create_draft_batch(
    batch_name: str, deposit_date: str, estimated_report_date: str, created_by: int
) -> Batch:
    code = _next_batch_code()
    final_name = _unique_display_name(batch_name.strip())
    with db_cursor() as cur:
        cur.execute(
            """
            INSERT INTO batches (batch_code, batch_name, deposit_date, estimated_report_date, status, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (code, final_name, deposit_date, estimated_report_date, BATCH_DRAFT, created_by),
        )
        batch_id = cur.lastrowid
        cur.execute("SELECT * FROM batches WHERE id = ?", (batch_id,))
        row = cur.fetchone()
    return Batch.from_row(row)


def open_batch(batch_id: int) -> None:
    with db_cursor() as cur:
        cur.execute(
            "UPDATE batches SET status = ?, opened_at = ? WHERE id = ?",
            (BATCH_OPEN, _now_iso(), batch_id),
        )


def discard_draft_batch(batch_id: int) -> None:
    """Batal buat batch (tombol BATAL saat konfirmasi). Hapus permanen
    karena statusnya masih DRAFT, belum pernah dipakai user."""
    with db_cursor() as cur:
        cur.execute("DELETE FROM batches WHERE id = ? AND status = ?", (batch_id, BATCH_DRAFT))


def lock_batch(batch_id: int) -> None:
    with db_cursor() as cur:
        cur.execute(
            "UPDATE batches SET status = ?, locked_at = ? WHERE id = ?",
            (BATCH_LOCKED, _now_iso(), batch_id),
        )


def mark_report_ready(batch_id: int) -> None:
    with db_cursor() as cur:
        cur.execute(
            "UPDATE batches SET status = ?, report_ready_at = ? WHERE id = ?",
            (BATCH_REPORT_READY, _now_iso(), batch_id),
        )


def get_batch(batch_id: int) -> Optional[Batch]:
    with db_cursor() as cur:
        cur.execute("SELECT * FROM batches WHERE id = ?", (batch_id,))
        row = cur.fetchone()
    return Batch.from_row(row) if row else None


def get_batch_by_code(batch_code: str) -> Optional[Batch]:
    with db_cursor() as cur:
        cur.execute("SELECT * FROM batches WHERE batch_code = ?", (batch_code,))
        row = cur.fetchone()
    return Batch.from_row(row) if row else None


def list_batches_by_status(statuses: list[str]) -> list[Batch]:
    placeholders = ",".join("?" for _ in statuses)
    with db_cursor() as cur:
        cur.execute(
            f"SELECT * FROM batches WHERE status IN ({placeholders}) ORDER BY id ASC",
            statuses,
        )
        rows = cur.fetchall()
    return [Batch.from_row(r) for r in rows]


def list_all_active_batches() -> list[Batch]:
    """Semua batch yang belum di-purge (dipakai untuk cek duplicate scope)."""
    with db_cursor() as cur:
        cur.execute(
            "SELECT * FROM batches WHERE status != ? ORDER BY id ASC",
            (BATCH_PURGED,),
        )
        rows = cur.fetchall()
    return [Batch.from_row(r) for r in rows]


def list_batches_user_participated(user_id: int) -> list[Batch]:
    """Batch yang pernah diikuti user tertentu DAN datanya masih ada
    (belum purge) — dipakai di menu 'Cek Gmail' / 'Batch Saya'."""
    with db_cursor() as cur:
        cur.execute(
            """
            SELECT DISTINCT b.* FROM batches b
            JOIN emails e ON e.batch_id = b.id
            WHERE e.user_id = ? AND b.status != ?
            ORDER BY b.id ASC
            """,
            (user_id, BATCH_PURGED),
        )
        rows = cur.fetchall()
    return [Batch.from_row(r) for r in rows]


# ═══════════════════════════════════════════════════════════════════════
# SUBMISSIONS & EMAILS (duplicate checking, parsing hasil, dst)
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class SubmissionResult:
    submission_code: str
    total_input: int
    total_saved: int
    total_duplicate: int
    total_invalid_format: int
    duplicate_details: list[tuple[str, str]]  # (email, batch_code asal)


def find_existing_email_batches(emails: list[str]) -> dict[str, str]:
    """Untuk daftar email, cari yang SUDAH ADA di batch manapun yang masih
    aktif (belum purge). Return {email: batch_code_asal}.

    Ini inti dari Rule 4 & 5: duplicate check lintas batch, selama data
    batch lama masih tersimpan (belum di-purge). Karena baris yang purge
    otomatis terhapus dari tabel emails (lihat purge_batch), query simpel
    "email exists in table emails" sudah otomatis benar secara scope —
    tidak perlu filter status batch tambahan di sini.
    """
    if not emails:
        return {}
    placeholders = ",".join("?" for _ in emails)
    with db_cursor() as cur:
        cur.execute(
            f"""
            SELECT e.email, b.batch_code
            FROM emails e
            JOIN batches b ON b.id = e.batch_id
            WHERE e.email IN ({placeholders})
            """,
            emails,
        )
        rows = cur.fetchall()
    return {r["email"]: r["batch_code"] for r in rows}


def save_submission(
    batch_id: int,
    user_id: int,
    valid_unique: list[str],
    total_input: int,
    total_invalid_format: int,
) -> SubmissionResult:
    """Simpan submission baru + insert email yang lolos duplicate check.

    Alur:
        1. Cek mana dari `valid_unique` yang sudah ada di batch aktif lain
           (atau di batch ini sendiri, dari submission sebelumnya).
        2. Insert hanya yang belum ada.
        3. Catat submission_id terpisah (Rule: setiap kirim = submission baru).
    """
    existing_map = find_existing_email_batches(valid_unique)

    to_insert = [e for e in valid_unique if e not in existing_map]
    duplicates = [(e, existing_map[e]) for e in valid_unique if e in existing_map]

    submission_code = _gen_code("SUB")

    with db_cursor() as cur:
        cur.execute(
            """
            INSERT INTO submissions
                (submission_code, batch_id, user_id, total_input,
                 total_saved, total_duplicate, total_invalid_format)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                submission_code,
                batch_id,
                user_id,
                total_input,
                len(to_insert),
                len(duplicates),
                total_invalid_format,
            ),
        )
        submission_id = cur.lastrowid

        now = _now_iso()
        for email in to_insert:
            cur.execute(
                """
                INSERT INTO emails (submission_id, batch_id, user_id, email, status, submitted_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (submission_id, batch_id, user_id, email, EMAIL_PENDING, now),
            )

    return SubmissionResult(
        submission_code=submission_code,
        total_input=total_input,
        total_saved=len(to_insert),
        total_duplicate=len(duplicates),
        total_invalid_format=total_invalid_format,
        duplicate_details=duplicates,
    )


@dataclass
class MatchingResult:
    total_invalid_input: int
    matched: int
    not_found: list[str]


def apply_invalid_report(batch_id: int, invalid_emails: list[str]) -> MatchingResult:
    """Terapkan daftar email invalid ke batch: email yang cocok -> INVALID,
    sisanya (yang masih PENDING) -> VALID. Email invalid yang tidak
    ditemukan dalam batch TIDAK dibuat sebagai record baru (sesuai
    keputusan: cukup dilaporkan sekali ke admin, tidak disimpan)."""
    unique_invalid = list(dict.fromkeys(invalid_emails))  # dedup, preserve order

    with db_cursor() as cur:
        # Cari mana yang benar-benar ada di batch ini.
        placeholders = ",".join("?" for _ in unique_invalid) if unique_invalid else None
        found_emails: set[str] = set()
        if unique_invalid:
            cur.execute(
                f"""
                SELECT email FROM emails
                WHERE batch_id = ? AND email IN ({placeholders})
                """,
                [batch_id, *unique_invalid],
            )
            found_emails = {r["email"] for r in cur.fetchall()}

        not_found = [e for e in unique_invalid if e not in found_emails]

        # Set status INVALID untuk yang matched.
        if found_emails:
            found_list = list(found_emails)
            fp = ",".join("?" for _ in found_list)
            cur.execute(
                f"""
                UPDATE emails SET status = ?
                WHERE batch_id = ? AND email IN ({fp})
                """,
                [EMAIL_INVALID, batch_id, *found_list],
            )

        # Sisanya yang masih PENDING di batch ini -> VALID.
        cur.execute(
            "UPDATE emails SET status = ? WHERE batch_id = ? AND status = ?",
            (EMAIL_VALID, batch_id, EMAIL_PENDING),
        )

    return MatchingResult(
        total_invalid_input=len(unique_invalid),
        matched=len(found_emails),
        not_found=not_found,
    )


@dataclass
class UserBatchSummary:
    total: int
    valid: int
    invalid: int
    pending: int
    invalid_emails: list[str]


def get_user_batch_summary(batch_id: int, user_id: int) -> UserBatchSummary:
    with db_cursor() as cur:
        cur.execute(
            "SELECT status, email FROM emails WHERE batch_id = ? AND user_id = ?",
            (batch_id, user_id),
        )
        rows = cur.fetchall()
    total = len(rows)
    valid = sum(1 for r in rows if r["status"] == EMAIL_VALID)
    invalid = sum(1 for r in rows if r["status"] == EMAIL_INVALID)
    pending = sum(1 for r in rows if r["status"] == EMAIL_PENDING)
    invalid_emails = sorted(r["email"] for r in rows if r["status"] == EMAIL_INVALID)
    return UserBatchSummary(
        total=total, valid=valid, invalid=invalid, pending=pending, invalid_emails=invalid_emails
    )


@dataclass
class BatchStatistics:
    total_user: int
    total_gmail: int
    total_valid: int
    total_invalid: int
    total_pending: int
    total_confirmed: int


def get_batch_statistics(batch_id: int) -> BatchStatistics:
    with db_cursor() as cur:
        cur.execute(
            "SELECT COUNT(DISTINCT user_id) AS n FROM emails WHERE batch_id = ?",
            (batch_id,),
        )
        total_user = cur.fetchone()["n"]

        cur.execute(
            """
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'VALID' THEN 1 ELSE 0 END) AS valid,
                SUM(CASE WHEN status = 'INVALID' THEN 1 ELSE 0 END) AS invalid,
                SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) AS pending
            FROM emails WHERE batch_id = ?
            """,
            (batch_id,),
        )
        row = cur.fetchone()

        cur.execute(
            "SELECT COUNT(*) AS n FROM confirmations WHERE batch_id = ?",
            (batch_id,),
        )
        total_confirmed = cur.fetchone()["n"]

    return BatchStatistics(
        total_user=total_user,
        total_gmail=row["total"] or 0,
        total_valid=row["valid"] or 0,
        total_invalid=row["invalid"] or 0,
        total_pending=row["pending"] or 0,
        total_confirmed=total_confirmed,
    )


def list_batch_participants(batch_id: int) -> list[int]:
    """Daftar internal user_id yang punya email di batch ini."""
    with db_cursor() as cur:
        cur.execute(
            "SELECT DISTINCT user_id FROM emails WHERE batch_id = ?", (batch_id,)
        )
        return [r["user_id"] for r in cur.fetchall()]


def list_unconfirmed_participants(batch_id: int) -> list[int]:
    participants = set(list_batch_participants(batch_id))
    with db_cursor() as cur:
        cur.execute(
            "SELECT user_id FROM confirmations WHERE batch_id = ?", (batch_id,)
        )
        confirmed = {r["user_id"] for r in cur.fetchall()}
    return sorted(participants - confirmed)


def get_user_batch_detail_for_admin(batch_id: int, user_id: int) -> UserBatchSummary:
    return get_user_batch_summary(batch_id, user_id)


# ═══════════════════════════════════════════════════════════════════════
# CONFIRMATIONS
# ═══════════════════════════════════════════════════════════════════════

def has_confirmed(batch_id: int, user_id: int) -> bool:
    with db_cursor() as cur:
        cur.execute(
            "SELECT 1 FROM confirmations WHERE batch_id = ? AND user_id = ?",
            (batch_id, user_id),
        )
        return cur.fetchone() is not None


def confirm_batch_result(batch_id: int, user_id: int) -> None:
    with db_cursor() as cur:
        cur.execute(
            """
            INSERT INTO confirmations (batch_id, user_id, confirmed_at)
            VALUES (?, ?, ?)
            ON CONFLICT(batch_id, user_id) DO NOTHING
            """,
            (batch_id, user_id, _now_iso()),
        )


# ═══════════════════════════════════════════════════════════════════════
# EXPORT DATA (untuk export.py)
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class EmailExportRow:
    no: int
    user_label: str
    email: str
    status: str
    submission_code: str
    submitted_at: str


def get_batch_export_rows(batch_id: int) -> list[EmailExportRow]:
    with db_cursor() as cur:
        cur.execute(
            """
            SELECT e.email, e.status, e.submitted_at, s.submission_code,
                   u.username, u.telegram_user_id
            FROM emails e
            JOIN submissions s ON s.id = e.submission_id
            JOIN users u ON u.id = e.user_id
            WHERE e.batch_id = ?
            ORDER BY e.id ASC
            """,
            (batch_id,),
        )
        rows = cur.fetchall()
    result = []
    for i, r in enumerate(rows, start=1):
        label = f"@{r['username']}" if r["username"] else f"id:{r['telegram_user_id']}"
        result.append(
            EmailExportRow(
                no=i,
                user_label=label,
                email=r["email"],
                status=r["status"],
                submission_code=r["submission_code"],
                submitted_at=r["submitted_at"],
            )
        )
    return result


def get_user_export_rows(batch_id: int, user_id: int) -> list[EmailExportRow]:
    all_rows = get_batch_export_rows(batch_id)
    with db_cursor() as cur:
        cur.execute("SELECT telegram_user_id, username FROM users WHERE id = ?", (user_id,))
        u = cur.fetchone()
    label = f"@{u['username']}" if u and u["username"] else f"id:{u['telegram_user_id']}" if u else "unknown"
    filtered = [r for r in all_rows if r.user_label == label]
    # re-number
    return [
        EmailExportRow(no=i, user_label=r.user_label, email=r.email, status=r.status,
                        submission_code=r.submission_code, submitted_at=r.submitted_at)
        for i, r in enumerate(filtered, start=1)
    ]


@dataclass
class UserRecapRow:
    """Satu baris rekap per-user (bukan per-email), dipakai untuk export
    data batch dan backup sebelum purge — format ringkas 1 baris = 1 user."""

    no: int
    user_label: str
    total_gmail: int
    total_valid: int
    total_invalid: int
    emails_all: list[str]
    emails_valid: list[str]
    emails_invalid: list[str]


def get_batch_user_recap(batch_id: int) -> list[UserRecapRow]:
    """Rekap per user untuk satu batch: total setor, valid, invalid,
    beserta daftar emailnya masing-masing. Urut berdasarkan user_id
    (konsisten dengan urutan setoran pertama kali)."""
    with db_cursor() as cur:
        cur.execute(
            """
            SELECT e.user_id, e.email, e.status, u.username, u.telegram_user_id
            FROM emails e
            JOIN users u ON u.id = e.user_id
            WHERE e.batch_id = ?
            ORDER BY e.user_id ASC, e.id ASC
            """,
            (batch_id,),
        )
        rows = cur.fetchall()

    per_user: dict[int, dict] = {}
    order: list[int] = []
    for r in rows:
        uid = r["user_id"]
        if uid not in per_user:
            label = f"@{r['username']}" if r["username"] else f"id:{r['telegram_user_id']}"
            per_user[uid] = {"label": label, "all": [], "valid": [], "invalid": []}
            order.append(uid)
        per_user[uid]["all"].append(r["email"])
        if r["status"] == EMAIL_VALID:
            per_user[uid]["valid"].append(r["email"])
        elif r["status"] == EMAIL_INVALID:
            per_user[uid]["invalid"].append(r["email"])

    result = []
    for i, uid in enumerate(order, start=1):
        d = per_user[uid]
        result.append(
            UserRecapRow(
                no=i,
                user_label=d["label"],
                total_gmail=len(d["all"]),
                total_valid=len(d["valid"]),
                total_invalid=len(d["invalid"]),
                emails_all=d["all"],
                emails_valid=d["valid"],
                emails_invalid=d["invalid"],
            )
        )
    return result


# ═══════════════════════════════════════════════════════════════════════
# PURGE
# ═══════════════════════════════════════════════════════════════════════

def purge_batch(batch_id: int) -> None:
    """Hapus seluruh data granular batch (submissions, emails,
    confirmations), pertahankan metadata ringan di tabel batches
    (sesuai §22)."""
    stats = get_batch_statistics(batch_id)

    with db_cursor() as cur:
        cur.execute("DELETE FROM emails WHERE batch_id = ?", (batch_id,))
        cur.execute("DELETE FROM submissions WHERE batch_id = ?", (batch_id,))
        cur.execute("DELETE FROM confirmations WHERE batch_id = ?", (batch_id,))
        cur.execute(
            """
            UPDATE batches
            SET status = ?, purged_at = ?, purged_total_user = ?, purged_total_gmail = ?
            WHERE id = ?
            """,
            (BATCH_PURGED, _now_iso(), stats.total_user, stats.total_gmail, batch_id),
        )
