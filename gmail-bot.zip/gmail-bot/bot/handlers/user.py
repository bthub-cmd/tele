"""
Handler untuk semua interaksi user biasa (bukan admin):
    - Setor Gmail
    - Cek Gmail (hasil validasi)
    - Batch Saya
    - Konfirmasi hasil

Semua akses data di sini WAJIB difilter berdasarkan user_id milik user
yang sedang berinteraksi (Security Rule §29 no.1 & no.2) — user tidak
boleh pernah melihat data user lain.
"""

from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from bot import models
from bot.handlers.common import send_long_text
from bot.keyboards import (
    batch_selection_keyboard,
    confirmation_button,
    main_user_menu,
)
from bot.states import (
    BATCH_LOCKED,
    BATCH_OPEN,
    BATCH_REPORT_READY,
    USER_IDLE,
    USER_SELECT_BATCH,
    USER_SELECT_CHECK_BATCH,
    USER_WAITING_GMAIL_LIST,
)
from bot.validators import parse_gmail_list


# ═══════════════════════════════════════════════════════════════════════
# SETOR GMAIL
# ═══════════════════════════════════════════════════════════════════════

async def cb_user_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Tombol '📥 Setor Gmail' ditekan -> tampilkan batch yang OPEN."""
    query = update.callback_query
    await query.answer()
    tg_user = update.effective_user

    open_batches = models.list_batches_by_status([BATCH_OPEN])
    if not open_batches:
        await query.edit_message_text("📭 Tidak ada batch yang sedang dibuka saat ini.\n\nSilakan cek kembali nanti.")
        return

    models.set_user_state(tg_user.id, USER_SELECT_BATCH, {})
    await query.edit_message_text(
        "📋 <b>Pilih Batch</b>\n\nBatch yang tersedia untuk setoran:",
        reply_markup=batch_selection_keyboard(open_batches, "user:selectbatch"),
        parse_mode="HTML",
    )


async def cb_user_select_batch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """User memilih salah satu batch dari daftar -> minta kirim list gmail."""
    query = update.callback_query
    await query.answer()
    tg_user = update.effective_user

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)

    if batch is None or batch.status != BATCH_OPEN:
        await query.edit_message_text("🔒 Batch sudah ditutup.\n\nSetoran baru tidak dapat dilakukan.")
        models.set_user_state(tg_user.id, USER_IDLE, {})
        return

    models.set_user_state(tg_user.id, USER_WAITING_GMAIL_LIST, {"batch_id": batch_id})
    await query.edit_message_text(
        f"📥 <b>Kirim List Gmail</b>\n\n"
        f"Batch: <b>{batch.display_name}</b>\n\n"
        f"Kirim daftar Gmail, satu Gmail per baris. Contoh:\n"
        f"<code>budi@gmail.com\njajang@gmail.com</code>\n\n"
        f"Ketik /cancel untuk membatalkan.",
        parse_mode="HTML",
    )


async def handle_gmail_list_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Menangani teks yang dikirim user saat state == USER_WAITING_GMAIL_LIST."""
    tg_user = update.effective_user
    state, ctx = models.get_user_state(tg_user.id)
    if state != USER_WAITING_GMAIL_LIST:
        return  # bukan urusan handler ini; dibiarkan lolos (tidak match)

    batch_id = ctx.get("batch_id")
    batch = models.get_batch(batch_id) if batch_id else None

    if batch is None or batch.status != BATCH_OPEN:
        await update.message.reply_text(
            "🔒 Batch sudah ditutup.\n\nSetoran baru tidak dapat dilakukan.",
            reply_markup=main_user_menu(),
        )
        models.set_user_state(tg_user.id, USER_IDLE, {})
        return

    raw_text = update.message.text or ""
    parsed = parse_gmail_list(raw_text)

    if parsed.total_input == 0:
        await update.message.reply_text("❌ List kosong.\nSilakan kirim Gmail.")
        return

    if not parsed.valid_unique and not parsed.duplicate_in_submission:
        await update.message.reply_text(
            "❌ Tidak ditemukan Gmail dengan format yang valid.\n\n"
            "Pastikan menggunakan alamat @gmail.com yang valid."
        )
        return

    internal_user_id = models.get_or_create_user(tg_user.id, tg_user.username)

    result = models.save_submission(
        batch_id=batch.id,
        user_id=internal_user_id,
        valid_unique=parsed.valid_unique,
        total_input=parsed.total_input,
        total_invalid_format=len(parsed.invalid_format),
    )

    total_duplicate_all = result.total_duplicate + len(parsed.duplicate_in_submission)

    if result.total_saved == 0 and total_duplicate_all > 0:
        text = "⚠️ Semua Gmail yang Anda kirim sudah pernah terdaftar sebelumnya.\n\nTidak ada Gmail baru yang disimpan."
    else:
        text = (
            "✅ <b>Setoran Berhasil Diproses</b>\n\n"
            f"Total diterima: {parsed.total_input}\n"
            f"✅ Berhasil disimpan: {result.total_saved}\n"
            f"⚠️ Duplicate: {total_duplicate_all}\n"
            f"❌ Format invalid: {len(parsed.invalid_format)}"
        )

    await update.message.reply_text(text, reply_markup=main_user_menu(), parse_mode="HTML")
    models.set_user_state(tg_user.id, USER_IDLE, {})


# ═══════════════════════════════════════════════════════════════════════
# CEK GMAIL
# ═══════════════════════════════════════════════════════════════════════

async def cb_user_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    tg_user = update.effective_user

    internal_user_id = models.get_or_create_user(tg_user.id, tg_user.username)
    batches = models.list_batches_user_participated(internal_user_id)

    if not batches:
        await query.edit_message_text("📭 Anda belum pernah menyetor Gmail ke batch manapun.")
        return

    models.set_user_state(tg_user.id, USER_SELECT_CHECK_BATCH, {})

    lines = []
    for b in batches:
        status_label = "📊 Report tersedia" if b.status == BATCH_REPORT_READY else "⏳ Menunggu report"
        lines.append(f"<b>{b.display_name}</b> — {status_label}")

    await query.edit_message_text(
        "📋 <b>Pilih Batch</b>\n\n" + "\n".join(lines),
        reply_markup=batch_selection_keyboard(batches, "user:checkbatch"),
        parse_mode="HTML",
    )


async def cb_user_check_batch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    tg_user = update.effective_user

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    internal_user_id = models.get_or_create_user(tg_user.id, tg_user.username)

    if batch is None:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    if batch.status != BATCH_REPORT_READY:
        await query.edit_message_text(
            "⏳ <b>Report Belum Tersedia</b>\n\n"
            f"Batch: <b>{batch.display_name}</b>\n"
            f"Perkiraan report: {batch.estimated_report_date}\n\n"
            "Silakan cek kembali setelah report tersedia.",
            parse_mode="HTML",
        )
        models.set_user_state(tg_user.id, USER_IDLE, {})
        return

    summary = models.get_user_batch_summary(batch.id, internal_user_id)

    if summary.total == 0:
        await query.edit_message_text("❌ Anda tidak memiliki data pada batch ini.")
        return

    header_text = (
        f"📊 <b>Hasil Validasi — {batch.display_name}</b>\n\n"
        f"Tanggal Setoran: {batch.deposit_date}\n"
        f"Total Gmail: {summary.total}\n"
        f"✅ Valid: {summary.valid}\n"
        f"❌ Invalid: {summary.invalid}"
    )

    await query.edit_message_text(header_text, parse_mode="HTML")

    if summary.invalid_emails:
        lines = [f"{i+1}. {email}" for i, email in enumerate(summary.invalid_emails)]
        await send_long_text(
            context=context,
            chat_id=update.effective_chat.id,
            header="❌ Gmail Invalid Anda",
            lines=lines,
            footer=f"Total Invalid: {summary.invalid}",
            reply_markup=confirmation_button(batch.id),
        )
    else:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="🎉 Semua Gmail Anda VALID! Tidak ada yang invalid.",
            reply_markup=confirmation_button(batch.id),
        )

    models.set_user_state(tg_user.id, USER_IDLE, {})


# ═══════════════════════════════════════════════════════════════════════
# KONFIRMASI
# ═══════════════════════════════════════════════════════════════════════

async def cb_user_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    tg_user = update.effective_user

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    internal_user_id = models.get_or_create_user(tg_user.id, tg_user.username)

    if batch is None or batch.status != BATCH_REPORT_READY:
        await query.edit_message_text("⏳ Report invalid belum tersedia.")
        return

    models.confirm_batch_result(batch.id, internal_user_id)

    await query.edit_message_text(
        f"✅ <b>Hasil Dikonfirmasi</b>\n\n"
        f"Batch: <b>{batch.display_name}</b>\n\n"
        "Terima kasih sudah memeriksa hasil validasi Anda.",
        parse_mode="HTML",
    )


# ═══════════════════════════════════════════════════════════════════════
# BATCH SAYA
# ═══════════════════════════════════════════════════════════════════════

async def cb_user_mybatches(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    tg_user = update.effective_user

    internal_user_id = models.get_or_create_user(tg_user.id, tg_user.username)
    batches = models.list_batches_user_participated(internal_user_id)

    if not batches:
        await query.edit_message_text("📭 Anda belum pernah menyetor Gmail ke batch manapun.")
        return

    lines = []
    for b in batches:
        summary = models.get_user_batch_summary(b.id, internal_user_id)
        confirmed = "✅" if models.has_confirmed(b.id, internal_user_id) else "⏳"
        lines.append(
            f"<b>{b.display_name}</b>\n"
            f"   Total: {summary.total} | Valid: {summary.valid} | Invalid: {summary.invalid} {confirmed}"
        )

    await query.edit_message_text("📋 <b>Batch Saya</b>\n\n" + "\n\n".join(lines), parse_mode="HTML")
