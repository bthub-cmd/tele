"""
Handler umum: /start, /cancel, /admin (entry point), dan helper bersama
yang dipakai oleh handler user maupun admin.
"""

from __future__ import annotations

import asyncio

from telegram import Update
from telegram.ext import ContextTypes

from bot import models
from bot.config import (
    MULTI_MESSAGE_DELAY,
    TELEGRAM_MAX_MESSAGE_LENGTH,
    is_admin,
)
from bot.keyboards import main_admin_menu, main_user_menu
from bot.states import ADMIN_IDLE, USER_IDLE


async def send_long_text(
    context: ContextTypes.DEFAULT_TYPE,
    chat_id: int,
    header: str,
    lines: list[str],
    footer: str = "",
    reply_markup=None,
    parse_mode: str | None = "HTML",
) -> None:
    """Kirim daftar baris yang berpotensi panjang, dipecah menjadi
    beberapa pesan agar tidak melebihi batas Telegram (sesuai §19).

    header dan footer ditampilkan di pesan pertama & terakhir; jika hanya
    1 bagian, keduanya digabung dalam satu pesan.
    """
    if not lines:
        text = header + ("\n\n" + footer if footer else "")
        await context.bot.send_message(chat_id=chat_id, text=text, reply_markup=reply_markup, parse_mode=parse_mode)
        return

    # Susun baris menjadi chunk-chunk teks yang aman panjangnya.
    chunks: list[str] = []
    current = ""
    for line in lines:
        candidate = (current + "\n" + line) if current else line
        if len(candidate) > TELEGRAM_MAX_MESSAGE_LENGTH:
            if current:
                chunks.append(current)
            current = line
        else:
            current = candidate
    if current:
        chunks.append(current)

    total_parts = len(chunks)

    for idx, chunk in enumerate(chunks, start=1):
        part_label = f" (bagian {idx}/{total_parts})" if total_parts > 1 else ""
        text = f"<b>{header}{part_label}</b>\n\n{chunk}"

        is_last = idx == total_parts
        markup = reply_markup if is_last else None
        final_text = text if not is_last else (text + (f"\n\n{footer}" if footer else ""))

        await context.bot.send_message(chat_id=chat_id, text=final_text, reply_markup=markup, parse_mode=parse_mode)

        if not is_last:
            await asyncio.sleep(MULTI_MESSAGE_DELAY)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    models.get_or_create_user(user.id, user.username)
    models.set_user_state(user.id, USER_IDLE, {})

    if is_admin(user.id):
        text = (
            "👋 <b>Selamat datang, Admin!</b>\n\n"
            "Ketik /admin untuk membuka panel admin, atau pilih menu di bawah "
            "untuk mode user biasa."
        )
    else:
        text = "👋 <b>Selamat datang di Gmail Validation Bot!</b>\n\nSilakan pilih menu di bawah."

    await update.message.reply_text(text, reply_markup=main_user_menu(), parse_mode="HTML")


async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not is_admin(user.id):
        await update.message.reply_text("❌ Anda tidak memiliki akses admin.")
        return

    models.get_or_create_user(user.id, user.username)
    models.set_user_state(user.id, ADMIN_IDLE, {})

    # Reminder on-demand (sesuai keputusan): cek batch yang "menggantung".
    from bot.handlers.admin import build_admin_reminders  # local import: hindari circular import

    reminder_text = await build_admin_reminders()

    text = "👑 <b>Panel Admin</b>"
    if reminder_text:
        text = reminder_text + "\n\n" + text

    await update.message.reply_text(text, reply_markup=main_admin_menu(), parse_mode="HTML")


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if is_admin(user.id):
        models.set_user_state(user.id, ADMIN_IDLE, {})
        await update.message.reply_text("❌ Dibatalkan.", reply_markup=main_admin_menu())
    else:
        models.set_user_state(user.id, USER_IDLE, {})
        await update.message.reply_text("❌ Dibatalkan.", reply_markup=main_user_menu())


async def cb_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handler untuk tombol inline 'Batal' generik."""
    query = update.callback_query
    await query.answer()
    user = update.effective_user
    if is_admin(user.id):
        models.set_user_state(user.id, ADMIN_IDLE, {})
        await query.edit_message_text("❌ Dibatalkan.")
        await context.bot.send_message(
            chat_id=update.effective_chat.id, text="👑 <b>Panel Admin</b>", reply_markup=main_admin_menu(), parse_mode="HTML"
        )
    else:
        models.set_user_state(user.id, USER_IDLE, {})
        await query.edit_message_text("❌ Dibatalkan.")
        await context.bot.send_message(
            chat_id=update.effective_chat.id, text="📱 <b>Menu Utama</b>", reply_markup=main_user_menu(), parse_mode="HTML"
        )
