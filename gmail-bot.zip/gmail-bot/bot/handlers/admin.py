"""
Handler untuk semua interaksi admin.

Setiap handler WAJIB memverifikasi is_admin() di awal (Security Rule
§29 no.9: semua callback/button harus memverifikasi role user) meskipun
secara UI tombol admin hanya muncul di menu admin — proteksi ini penting
karena callback_data bisa saja "ditebak"/direplay oleh user lain.
"""

from __future__ import annotations

import os

from telegram import Update
from telegram.ext import ContextTypes

from bot import models
from bot.config import is_admin
from bot.export import (
    export_batch_raw_txt,
    export_batch_raw_xlsx,
    export_recap_txt,
    export_recap_xlsx,
    export_single_user_txt,
    export_single_user_xlsx,
)
from bot.handlers.common import send_long_text
from bot.keyboards import (
    batch_selection_keyboard,
    confirm_lock_batch_keyboard,
    confirm_open_batch_keyboard,
    export_format_keyboard,
    export_scope_keyboard,
    main_admin_menu,
    purge_confirm_keyboard,
    user_selection_keyboard,
)
from bot.states import (
    ADMIN_CONFIRM_BATCH,
    ADMIN_CONFIRM_LOCK,
    ADMIN_IDLE,
    ADMIN_INPUT_BATCH_NAME,
    ADMIN_INPUT_DEPOSIT_DATE,
    ADMIN_INPUT_ESTIMATED_REPORT,
    ADMIN_SELECT_BATCH_FOR_EXPORT,
    ADMIN_SELECT_BATCH_FOR_INVALID,
    ADMIN_SELECT_BATCH_FOR_LOCK,
    ADMIN_SELECT_BATCH_FOR_PURGE,
    ADMIN_SELECT_BATCH_FOR_STATUS,
    ADMIN_SELECT_USER_FOR_EXPORT,
    ADMIN_WAITING_INVALID_LIST,
    BATCH_DRAFT,
    BATCH_LOCKED,
    BATCH_OPEN,
    BATCH_REPORT_READY,
    BATCH_STATUS_LABELS,
)
from bot.validators import parse_gmail_list


async def _guard_admin(update: Update) -> bool:
    """Return True jika user berhak lanjut; kirim pesan penolakan & return
    False jika bukan admin."""
    user = update.effective_user
    if is_admin(user.id):
        return True
    if update.callback_query:
        await update.callback_query.answer("❌ Anda tidak memiliki akses admin.", show_alert=True)
    elif update.message:
        await update.message.reply_text("❌ Anda tidak memiliki akses admin.")
    return False


async def _back_to_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Helper: kembalikan state ke IDLE dan tampilkan panel admin lagi."""
    models.set_user_state(update.effective_user.id, ADMIN_IDLE, {})
    await context.bot.send_message(
        chat_id=update.effective_chat.id, text="👑 Panel Admin", reply_markup=main_admin_menu()
    )


# ═══════════════════════════════════════════════════════════════════════
# REMINDER (on-demand, dipanggil dari cmd_admin di common.py)
# ═══════════════════════════════════════════════════════════════════════

async def build_admin_reminders() -> str:
    """Bangun teks reminder untuk batch yang 'menggantung':
    - LOCKED tapi belum ada invalid report (masih menunggu report).
    - REPORT_READY tapi belum semua user konfirmasi.
    Return string kosong jika tidak ada yang perlu diingatkan.
    """
    reminders = []

    locked_batches = models.list_batches_by_status([BATCH_LOCKED])
    if locked_batches:
        names = ", ".join(b.display_name for b in locked_batches)
        reminders.append(f"⏳ Menunggu invalid report: {names}")

    report_ready_batches = models.list_batches_by_status([BATCH_REPORT_READY])
    pending_confirm_names = []
    for b in report_ready_batches:
        unconfirmed = models.list_unconfirmed_participants(b.id)
        if unconfirmed:
            pending_confirm_names.append(f"{b.display_name} ({len(unconfirmed)} user)")
    if pending_confirm_names:
        reminders.append("⏳ Menunggu konfirmasi user: " + ", ".join(pending_confirm_names))

    if not reminders:
        return ""
    return "🔔 <b>Pengingat</b>\n" + "\n".join(reminders)


# ═══════════════════════════════════════════════════════════════════════
# OPEN BATCH — 3 pertanyaan: Nama Batch → Tanggal Setoran → Perkiraan Report
# ═══════════════════════════════════════════════════════════════════════

async def cb_admin_open(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    models.set_user_state(update.effective_user.id, ADMIN_INPUT_BATCH_NAME, {})
    await query.edit_message_text(
        "🆕 <b>Buka Batch Baru</b>\n\n"
        "Langkah 1/3 — Masukkan <b>Nama Batch</b>:\n"
        "<i>(contoh: Campaign September, Batch Malam, dsb)</i>\n\n"
        "Ketik /cancel untuk membatalkan.",
        parse_mode="HTML",
    )


async def handle_batch_name_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    if not is_admin(tg_user.id):
        return
    state, ctx = models.get_user_state(tg_user.id)
    if state != ADMIN_INPUT_BATCH_NAME:
        return

    batch_name = (update.message.text or "").strip()
    if not batch_name:
        await update.message.reply_text("❌ Nama batch tidak boleh kosong. Coba lagi.")
        return
    if len(batch_name) > 100:
        await update.message.reply_text("❌ Nama batch maksimal 100 karakter. Coba lagi.")
        return

    models.set_user_state(tg_user.id, ADMIN_INPUT_DEPOSIT_DATE, {"batch_name": batch_name})
    await update.message.reply_text(
        f"✅ Nama batch: <b>{batch_name}</b>\n\n"
        "Langkah 2/3 — Masukkan <b>Tanggal Setoran</b>:\n"
        "<i>(contoh: 18 September 2026)</i>\n\n"
        "Ketik /cancel untuk membatalkan.",
        parse_mode="HTML",
    )


async def handle_deposit_date_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    if not is_admin(tg_user.id):
        return
    state, ctx = models.get_user_state(tg_user.id)
    if state != ADMIN_INPUT_DEPOSIT_DATE:
        return

    deposit_date = (update.message.text or "").strip()
    if not deposit_date:
        await update.message.reply_text("❌ Tanggal setoran tidak boleh kosong. Coba lagi.")
        return

    ctx["deposit_date"] = deposit_date
    models.set_user_state(tg_user.id, ADMIN_INPUT_ESTIMATED_REPORT, ctx)
    await update.message.reply_text(
        "Langkah 3/3 — Masukkan <b>Perkiraan Report Turun</b>:\n"
        "<i>(contoh: 19 September 2026)</i>\n\n"
        "Ketik /cancel untuk membatalkan.",
        parse_mode="HTML",
    )


async def handle_estimated_report_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    if not is_admin(tg_user.id):
        return
    state, ctx = models.get_user_state(tg_user.id)
    if state != ADMIN_INPUT_ESTIMATED_REPORT:
        return

    estimated_report = (update.message.text or "").strip()
    if not estimated_report:
        await update.message.reply_text("❌ Perkiraan report tidak boleh kosong. Coba lagi.")
        return

    batch_name = ctx.get("batch_name", "")
    deposit_date = ctx.get("deposit_date", "")
    internal_admin_id = models.get_or_create_user(tg_user.id, tg_user.username)

    batch = models.create_draft_batch(batch_name, deposit_date, estimated_report, internal_admin_id)

    models.set_user_state(tg_user.id, ADMIN_CONFIRM_BATCH, {"batch_id": batch.id})

    text = (
        "🆕 <b>Konfirmasi Batch</b>\n\n"
        f"Nama Batch:\n<b>{batch.display_name}</b>\n\n"
        f"Tanggal Setoran:\n{batch.deposit_date}\n\n"
        f"Perkiraan Report:\n{batch.estimated_report_date}\n\n"
        "Buka batch ini sekarang?"
    )
    await update.message.reply_text(text, reply_markup=confirm_open_batch_keyboard(batch.id), parse_mode="HTML")


async def cb_admin_confirm_open(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None or batch.status != BATCH_DRAFT:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah diproses.")
        return

    models.open_batch(batch_id)
    batch = models.get_batch(batch_id)

    text = (
        f"🟢 <b>{batch.display_name}</b> berhasil dibuka!\n\n"
        f"Tanggal Setoran: {batch.deposit_date}\n"
        f"Perkiraan Report: {batch.estimated_report_date}\n\n"
        "User sekarang bisa mulai menyetor Gmail ke batch ini."
    )
    await query.edit_message_text(text, parse_mode="HTML")
    await _back_to_admin_panel(update, context)


async def cb_admin_cancel_open(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    models.discard_draft_batch(batch_id)
    await query.edit_message_text("❌ Pembuatan batch dibatalkan.")
    await _back_to_admin_panel(update, context)


# ═══════════════════════════════════════════════════════════════════════
# LOCK BATCH — dengan konfirmasi
# ═══════════════════════════════════════════════════════════════════════

async def cb_admin_lock(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    open_batches = models.list_batches_by_status([BATCH_OPEN])
    if not open_batches:
        await query.edit_message_text("📭 Tidak ada batch berstatus OPEN untuk dikunci.")
        return

    models.set_user_state(update.effective_user.id, ADMIN_SELECT_BATCH_FOR_LOCK, {})
    await query.edit_message_text(
        "🔒 Pilih batch yang akan dikunci:",
        reply_markup=batch_selection_keyboard(open_batches, "admin:asklock"),
    )


async def cb_admin_ask_lock(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Setelah admin pilih batch, tampilkan dialog konfirmasi sebelum benar-benar lock."""
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None or batch.status != BATCH_OPEN:
        await query.edit_message_text("❌ Batch tidak ditemukan atau bukan status OPEN.")
        return

    stats = models.get_batch_statistics(batch_id)
    models.set_user_state(update.effective_user.id, ADMIN_CONFIRM_LOCK, {"batch_id": batch_id})
    text = (
        f"🔒 <b>Konfirmasi Lock Batch</b>\n\n"
        f"Batch: <b>{batch.display_name}</b>\n"
        f"Total user setor: {stats.total_user}\n"
        f"Total gmail masuk: {stats.total_gmail}\n\n"
        "Setelah dikunci, user <b>tidak bisa</b> menyetor lagi ke batch ini.\n"
        "Lanjutkan?"
    )
    await query.edit_message_text(text, reply_markup=confirm_lock_batch_keyboard(batch_id), parse_mode="HTML")


async def cb_admin_do_lock(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None or batch.status != BATCH_OPEN:
        await query.edit_message_text("❌ Batch tidak ditemukan atau bukan status OPEN.")
        return

    models.lock_batch(batch_id)
    batch = models.get_batch(batch_id)
    await query.edit_message_text(
        f"🔒 <b>{batch.display_name}</b> telah dikunci.\n\nMenunggu invalid report dari Anda.",
        parse_mode="HTML",
    )
    await _back_to_admin_panel(update, context)


# ═══════════════════════════════════════════════════════════════════════
# DAFTAR BATCH
# ═══════════════════════════════════════════════════════════════════════

async def cb_admin_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batches = models.list_all_active_batches()
    if not batches:
        await query.edit_message_text("📭 Belum ada batch aktif.")
        return

    status_emoji = {"OPEN": "🟢", "LOCKED": "🔒", "REPORT_READY": "📊", "DRAFT": "📝"}
    lines = []
    for b in batches:
        emoji = status_emoji.get(b.status, "")
        label = BATCH_STATUS_LABELS.get(b.status, b.status)
        lines.append(f"{emoji} <b>{b.display_name}</b>\n   {label} · Setoran: {b.deposit_date}")

    await query.edit_message_text("📋 <b>Daftar Batch Aktif</b>\n\n" + "\n\n".join(lines), parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════
# TAMBAH INVALID REPORT
# ═══════════════════════════════════════════════════════════════════════

async def cb_admin_invalid(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    locked_batches = models.list_batches_by_status([BATCH_LOCKED])
    if not locked_batches:
        await query.edit_message_text("📭 Tidak ada batch berstatus LOCKED yang menunggu report.")
        return

    models.set_user_state(update.effective_user.id, ADMIN_SELECT_BATCH_FOR_INVALID, {})
    await query.edit_message_text(
        "❌ Pilih batch untuk menambahkan invalid report:",
        reply_markup=batch_selection_keyboard(locked_batches, "admin:selectinvalidbatch"),
    )


async def cb_admin_select_invalid_batch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None or batch.status != BATCH_LOCKED:
        await query.edit_message_text("❌ Batch tidak ditemukan atau bukan status LOCKED.")
        return

    models.set_user_state(
        update.effective_user.id, ADMIN_WAITING_INVALID_LIST, {"batch_id": batch_id}
    )
    await query.edit_message_text(
        f"❌ Kirim daftar Gmail <b>INVALID</b> untuk <b>{batch.display_name}</b>.\n"
        f"Satu Gmail per baris.\n\n/cancel untuk batal",
        parse_mode="HTML",
    )


async def handle_invalid_list_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    if not is_admin(tg_user.id):
        return
    state, ctx = models.get_user_state(tg_user.id)
    if state != ADMIN_WAITING_INVALID_LIST:
        return

    batch_id = ctx.get("batch_id")
    batch = models.get_batch(batch_id) if batch_id else None
    if batch is None or batch.status != BATCH_LOCKED:
        await update.message.reply_text(
            "❌ Batch tidak ditemukan atau sudah tidak dalam status LOCKED.",
            reply_markup=main_admin_menu(),
        )
        models.set_user_state(tg_user.id, ADMIN_IDLE, {})
        return

    raw_text = update.message.text or ""
    parsed = parse_gmail_list(raw_text)

    if parsed.total_input == 0:
        await update.message.reply_text("❌ List kosong.\nSilakan kirim Gmail.")
        return

    all_invalid_emails = parsed.valid_unique + parsed.duplicate_in_submission

    processing_msg = await update.message.reply_text("⏳ Memproses matching...")

    match_result = models.apply_invalid_report(batch.id, all_invalid_emails)
    models.mark_report_ready(batch.id)

    text = (
        f"📊 <b>Invalid Report — {batch.display_name}</b>\n\n"
        f"Invalid diterima: {match_result.total_invalid_input}\n"
        f"✅ Berhasil matching: {match_result.matched}\n"
        f"⚠️ Tidak ditemukan: {len(match_result.not_found)}"
    )
    await update.message.reply_text(text, parse_mode="HTML")

    if match_result.not_found:
        lines = [f"• {e}" for e in match_result.not_found]
        await send_long_text(
            context=context,
            chat_id=update.effective_chat.id,
            header="⚠️ Email tidak ditemukan di batch ini",
            lines=lines,
        )

    await update.message.reply_text(
        f"✅ Report selesai diproses. User sudah bisa cek hasil validasi mereka."
    )
    await _back_to_admin_panel(update, context)


# ═══════════════════════════════════════════════════════════════════════
# STATUS CONFIRMATION
# ═══════════════════════════════════════════════════════════════════════

async def cb_admin_confirmstatus(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batches = models.list_batches_by_status([BATCH_REPORT_READY])
    if not batches:
        await query.edit_message_text("📭 Tidak ada batch dengan status Report Ready.")
        return

    models.set_user_state(update.effective_user.id, ADMIN_SELECT_BATCH_FOR_STATUS, {})
    await query.edit_message_text(
        "✅ Pilih batch untuk melihat status konfirmasi:",
        reply_markup=batch_selection_keyboard(batches, "admin:viewconfirmstatus"),
    )


async def cb_admin_view_confirm_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    stats = models.get_batch_statistics(batch_id)
    unconfirmed_ids = models.list_unconfirmed_participants(batch_id)

    text = (
        f"✅ <b>{batch.display_name}</b>\n\n"
        f"Total User: {stats.total_user}\n"
        f"Sudah Konfirmasi: {stats.total_confirmed}\n"
        f"Belum Konfirmasi: {len(unconfirmed_ids)}"
    )
    await query.edit_message_text(text, parse_mode="HTML")

    if unconfirmed_ids:
        lines = []
        for uid in unconfirmed_ids:
            summary = models.get_user_batch_detail_for_admin(batch_id, uid)
            label_map = models.get_username_map([uid])
            label = label_map.get(uid, f"id:{uid}")
            lines.append(f"👤 {label} — Total: {summary.total} | Valid: {summary.valid} | Invalid: {summary.invalid}")
        await send_long_text(
            context=context,
            chat_id=update.effective_chat.id,
            header="⚠️ User Belum Konfirmasi",
            lines=lines,
        )

    await _back_to_admin_panel(update, context)


# ═══════════════════════════════════════════════════════════════════════
# STATISTIK
# ═══════════════════════════════════════════════════════════════════════

async def cb_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batches = models.list_all_active_batches()
    if not batches:
        await query.edit_message_text("📭 Belum ada batch aktif.")
        return

    models.set_user_state(update.effective_user.id, ADMIN_SELECT_BATCH_FOR_STATUS, {"purpose": "stats"})
    await query.edit_message_text(
        "📈 Pilih batch untuk melihat statistik:",
        reply_markup=batch_selection_keyboard(batches, "admin:viewstats"),
    )


async def cb_admin_view_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    stats = models.get_batch_statistics(batch_id)
    label = BATCH_STATUS_LABELS.get(batch.status, batch.status)

    text = (
        f"📈 <b>Statistik — {batch.display_name}</b>\n\n"
        f"Status: {label}\n"
        f"Total User: {stats.total_user}\n"
        f"Total Gmail: {stats.total_gmail}\n"
        f"✅ Valid: {stats.total_valid}\n"
        f"❌ Invalid: {stats.total_invalid}\n"
        f"✍️ Confirmed: {stats.total_confirmed} / {stats.total_user}"
    )
    await query.edit_message_text(text, parse_mode="HTML")
    await _back_to_admin_panel(update, context)


# ═══════════════════════════════════════════════════════════════════════
# EXPORT DATA — format baru: rekap per user
# ═══════════════════════════════════════════════════════════════════════

async def cb_admin_export(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    await query.edit_message_text("📦 <b>Export Data</b>\n\nPilih jenis export:", reply_markup=export_scope_keyboard(), parse_mode="HTML")


async def cb_admin_export_scope(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    scope = query.data.split(":")[-1]  # 'batch' atau 'user'
    batches = models.list_all_active_batches()
    if not batches:
        await query.edit_message_text("📭 Belum ada batch aktif untuk diexport.")
        return

    models.set_user_state(
        update.effective_user.id, ADMIN_SELECT_BATCH_FOR_EXPORT, {"scope": scope}
    )
    prefix = "admin:exportbatchsel" if scope == "batch" else "admin:exportuserbatchsel"
    await query.edit_message_text(
        "Pilih batch:", reply_markup=batch_selection_keyboard(batches, prefix)
    )


async def cb_admin_export_batch_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    await query.edit_message_text(
        f"Format export untuk <b>{batch.display_name}</b>:",
        reply_markup=export_format_keyboard(batch_id, "batch"),
        parse_mode="HTML",
    )
    models.set_user_state(update.effective_user.id, ADMIN_IDLE, {})


async def cb_admin_export_user_batch_selected(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Setelah admin pilih batch untuk export-per-user, tampilkan daftar user di batch itu."""
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    participant_ids = models.list_batch_participants(batch_id)
    if not participant_ids:
        await query.edit_message_text("📭 Belum ada user yang menyetor pada batch ini.")
        return

    label_map = models.get_username_map(participant_ids)
    models.set_user_state(
        update.effective_user.id, ADMIN_SELECT_USER_FOR_EXPORT, {"batch_id": batch_id}
    )
    await query.edit_message_text(
        f"Pilih user pada <b>{batch.display_name}</b>:",
        reply_markup=user_selection_keyboard(label_map, batch_id),
        parse_mode="HTML",
    )


async def cb_admin_select_user_for_export(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    parts = query.data.split(":")
    batch_id = int(parts[-2])
    user_id = int(parts[-1])

    await query.edit_message_text(
        "Format export:",
        reply_markup=export_format_keyboard(batch_id, "user", user_id=user_id),
    )
    models.set_user_state(update.effective_user.id, ADMIN_IDLE, {})


async def _do_export_batch(update: Update, context: ContextTypes.DEFAULT_TYPE, batch_id: int, fmt: str) -> None:
    """Export seluruh batch, format rekap per user (Nama, Gmail Disetor, Total)."""
    batch = models.get_batch(batch_id)
    if batch is None:
        await update.callback_query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    recap = models.get_batch_user_recap(batch_id)
    if not recap:
        await update.callback_query.edit_message_text("📭 Tidak ada data untuk diexport.")
        return

    if fmt == "txt":
        path = export_batch_raw_txt(recap, batch.display_name.replace(" ", "_"))
    else:
        path = export_batch_raw_xlsx(recap, batch.display_name.replace(" ", "_"))

    await _send_export_file(update, context, path, fmt)


async def _do_export_user(update: Update, context: ContextTypes.DEFAULT_TYPE, batch_id: int, user_id: int, fmt: str) -> None:
    """Export data 1 user spesifik dalam batch tertentu."""
    batch = models.get_batch(batch_id)
    if batch is None:
        await update.callback_query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    recap = models.get_batch_user_recap(batch_id)
    label_map = models.get_username_map([user_id])
    target_label = label_map.get(user_id, f"id{user_id}")
    user_row = next((r for r in recap if r.user_label == target_label), None)

    if user_row is None:
        await update.callback_query.edit_message_text("📭 Tidak ada data untuk user ini.")
        return

    filename_hint = f"{batch.display_name}_{target_label.lstrip('@')}".replace(" ", "_")
    if fmt == "txt":
        path = export_single_user_txt(user_row, filename_hint)
    else:
        path = export_single_user_xlsx(user_row, filename_hint)

    await _send_export_file(update, context, path, fmt)


async def _send_export_file(update: Update, context: ContextTypes.DEFAULT_TYPE, path: str, fmt: str) -> None:
    query = update.callback_query
    await query.edit_message_text(f"📦 Menyiapkan file {fmt.upper()}...")
    try:
        with open(path, "rb") as f:
            await context.bot.send_document(chat_id=update.effective_chat.id, document=f, filename=os.path.basename(path))
    finally:
        try:
            os.remove(path)
        except OSError:
            pass

    await _back_to_admin_panel(update, context)


async def cb_admin_export_batch_txt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return
    batch_id = int(query.data.split(":")[-1])
    await _do_export_batch(update, context, batch_id, "txt")


async def cb_admin_export_batch_xlsx(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return
    batch_id = int(query.data.split(":")[-1])
    await _do_export_batch(update, context, batch_id, "xlsx")


async def cb_admin_export_user_txt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return
    parts = query.data.split(":")
    batch_id, user_id = int(parts[-2]), int(parts[-1])
    await _do_export_user(update, context, batch_id, user_id, "txt")


async def cb_admin_export_user_xlsx(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return
    parts = query.data.split(":")
    batch_id, user_id = int(parts[-2]), int(parts[-1])
    await _do_export_user(update, context, batch_id, user_id, "xlsx")


# ═══════════════════════════════════════════════════════════════════════
# PURGE BATCH — backup rekap per-user sebelum purge
# ═══════════════════════════════════════════════════════════════════════

async def cb_admin_purge(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batches = models.list_batches_by_status([BATCH_REPORT_READY])
    if not batches:
        await query.edit_message_text("📭 Tidak ada batch dengan status Report Ready yang bisa dipurge.")
        return

    models.set_user_state(update.effective_user.id, ADMIN_SELECT_BATCH_FOR_PURGE, {})
    await query.edit_message_text(
        "🗑 Pilih batch untuk di-purge:",
        reply_markup=batch_selection_keyboard(batches, "admin:selectpurge"),
    )


async def cb_admin_select_purge(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    stats = models.get_batch_statistics(batch_id)
    unconfirmed_ids = models.list_unconfirmed_participants(batch_id)

    # Sebelum purge: kirim rekap TXT + Excel per-user ke admin dulu (safety backup).
    await query.edit_message_text("📦 Menyiapkan rekap backup sebelum purge...")
    recap = models.get_batch_user_recap(batch_id)
    if recap:
        name_slug = batch.display_name.replace(" ", "_")
        txt_path = export_recap_txt(recap, f"backup_{name_slug}")
        xlsx_path = export_recap_xlsx(recap, f"backup_{name_slug}")
        try:
            with open(txt_path, "rb") as f:
                await context.bot.send_document(
                    chat_id=update.effective_chat.id, document=f, filename=os.path.basename(txt_path),
                    caption=f"📄 Backup TXT — {batch.display_name}"
                )
            with open(xlsx_path, "rb") as f:
                await context.bot.send_document(
                    chat_id=update.effective_chat.id, document=f, filename=os.path.basename(xlsx_path),
                    caption=f"📊 Backup Excel — {batch.display_name}"
                )
        finally:
            for p in (txt_path, xlsx_path):
                try:
                    os.remove(p)
                except OSError:
                    pass

    if unconfirmed_ids:
        label_map = models.get_username_map(unconfirmed_ids)
        names = ", ".join(label_map.get(uid, f"id:{uid}") for uid in unconfirmed_ids)
        text = (
            f"⚠️ <b>Batch Belum Selesai</b>\n\n"
            f"{stats.total_confirmed} / {stats.total_user} user sudah konfirmasi.\n\n"
            f"Belum konfirmasi:\n{names}\n\n"
            "Tetap hapus seluruh data batch ini?"
        )
        await context.bot.send_message(
            chat_id=update.effective_chat.id, text=text,
            reply_markup=purge_confirm_keyboard(batch_id, force=True),
            parse_mode="HTML",
        )
    else:
        text = (
            f"🗑 <b>{batch.display_name}</b>\n\n"
            f"{stats.total_confirmed} / {stats.total_user} user sudah konfirmasi.\n"
            "Data siap dihapus permanen."
        )
        await context.bot.send_message(
            chat_id=update.effective_chat.id, text=text,
            reply_markup=purge_confirm_keyboard(batch_id, force=False),
            parse_mode="HTML",
        )


async def cb_admin_do_purge(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Purge normal — hanya boleh jika semua user sudah confirm (dicek ulang di sini
    untuk mencegah race condition / manipulasi callback_data langsung)."""
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    unconfirmed_ids = models.list_unconfirmed_participants(batch_id)
    if unconfirmed_ids:
        await query.edit_message_text(
            "❌ Masih ada user yang belum konfirmasi. Gunakan Force Purge jika ingin tetap melanjutkan."
        )
        return

    models.purge_batch(batch_id)
    batch = models.get_batch(batch_id)
    await query.edit_message_text(
        f"🗑 <b>{batch.display_name}</b> telah dipurge.\n\n"
        f"Total User: {batch.purged_total_user}\n"
        f"Total Gmail: {batch.purged_total_gmail}",
        parse_mode="HTML",
    )
    await _back_to_admin_panel(update, context)


async def cb_admin_force_purge(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    if not await _guard_admin(update):
        return

    batch_id = int(query.data.split(":")[-1])
    batch = models.get_batch(batch_id)
    if batch is None:
        await query.edit_message_text("❌ Batch tidak ditemukan atau sudah tidak tersedia.")
        return

    models.purge_batch(batch_id)
    batch = models.get_batch(batch_id)
    await query.edit_message_text(
        f"⚠️ Force purge selesai — <b>{batch.display_name}</b>\n\n"
        f"Total User: {batch.purged_total_user}\n"
        f"Total Gmail: {batch.purged_total_gmail}",
        parse_mode="HTML",
    )
    await _back_to_admin_panel(update, context)
