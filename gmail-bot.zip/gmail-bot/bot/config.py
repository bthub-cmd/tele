"""
Konfigurasi bot.

Semua nilai sensitif (token bot, admin ID) diambil dari environment
variable, TIDAK di-hardcode di source code.

Cara set environment variable (Linux/Mac):
    export BOT_TOKEN="123456:ABC-DEF..."
    export ADMIN_IDS="111111111,222222222"

Atau buat file .env di root project (lihat README.md).
"""

from __future__ import annotations

import os
import sys

# ── Bot token ────────────────────────────────────────────────────────────
BOT_TOKEN: str = os.environ.get("BOT_TOKEN", "").strip()

# ── Admin whitelist ──────────────────────────────────────────────────────
# ADMIN_IDS diisi sebagai string angka Telegram user_id, dipisah koma.
# Contoh: ADMIN_IDS="111111111,222222222"
_raw_admin_ids = os.environ.get("ADMIN_IDS", "").strip()

ADMIN_IDS: frozenset[int] = frozenset()
if _raw_admin_ids:
    try:
        ADMIN_IDS = frozenset(
            int(x.strip()) for x in _raw_admin_ids.split(",") if x.strip()
        )
    except ValueError as exc:
        raise SystemExit(
            f"ADMIN_IDS tidak valid: '{_raw_admin_ids}'. "
            "Harus berupa angka dipisah koma, contoh: 111111111,222222222"
        ) from exc


def is_admin(user_id: int) -> bool:
    """Cek apakah user_id termasuk admin whitelist."""
    return user_id in ADMIN_IDS


# ── Database ─────────────────────────────────────────────────────────────
DB_PATH: str = os.environ.get("DB_PATH", "gmail_bot.db").strip()

# ── Batasan Telegram ─────────────────────────────────────────────────────
# Telegram membatasi panjang pesan ~4096 karakter. Kita pakai batas aman
# yang lebih kecil supaya tidak mepet.
TELEGRAM_MAX_MESSAGE_LENGTH: int = 3500

# Jeda antar pesan saat mengirim multi-part message (detik), untuk
# menghindari flood limit Telegram (rate limit per-chat ~1 pesan/detik).
MULTI_MESSAGE_DELAY: float = 0.6

# Berapa baris gmail per "halaman" saat menampilkan daftar invalid ke user.
GMAIL_LIST_PAGE_SIZE: int = 40

# ── Domain email yang diizinkan ──────────────────────────────────────────
# Sesuai keputusan bisnis: HANYA @gmail.com yang diterima. Domain lain
# (termasuk googlemail.com) ditolak sebagai format invalid.
ALLOWED_EMAIL_DOMAIN: str = "gmail.com"


def validate_config() -> None:
    """Validasi konfigurasi wajib sebelum bot dijalankan. Panggil di main.py."""
    problems: list[str] = []
    if not BOT_TOKEN:
        problems.append(
            "BOT_TOKEN belum di-set. Set environment variable BOT_TOKEN."
        )
    if not ADMIN_IDS:
        problems.append(
            "ADMIN_IDS belum di-set atau kosong. Set environment variable "
            "ADMIN_IDS, contoh: ADMIN_IDS=111111111,222222222"
        )
    if problems:
        print("KONFIGURASI TIDAK VALID:", file=sys.stderr)
        for p in problems:
            print(f"  - {p}", file=sys.stderr)
        raise SystemExit(1)
