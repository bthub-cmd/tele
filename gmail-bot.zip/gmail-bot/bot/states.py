"""
Konstanta state machine.

State disimpan per-user di tabel `user_states` (bukan hanya in-memory)
supaya kalau bot restart, user tidak nyangkut di flow yang aneh — mereka
akan mendapat pesan untuk /cancel dan mulai ulang saat interaksi berikutnya.

Batch status (lifecycle, sesuai spesifikasi §27):
    DRAFT                  -> baru dibuat, belum dikonfirmasi admin
    OPEN                   -> user boleh submit gmail
    LOCKED                 -> user tidak boleh submit lagi, menunggu report
    REPORT_READY            -> invalid report sudah masuk & matching selesai
    PURGED                  -> data sudah dihapus

Catatan: WAITING_REPORT dan WAITING_CONFIRMATION digabung secara implisit
melalui kombinasi status + progress confirmation, untuk menyederhanakan
implementasi (spesifikasi §27 mengizinkan penyederhanaan selama lifecycle
tetap jelas).
"""

from __future__ import annotations

# ── Batch status ─────────────────────────────────────────────────────────
BATCH_DRAFT = "DRAFT"
BATCH_OPEN = "OPEN"
BATCH_LOCKED = "LOCKED"
BATCH_REPORT_READY = "REPORT_READY"
BATCH_PURGED = "PURGED"

BATCH_STATUS_LABELS = {
    BATCH_DRAFT: "📝 DRAFT",
    BATCH_OPEN: "🟢 OPEN",
    BATCH_LOCKED: "🔒 LOCKED (Menunggu Report)",
    BATCH_REPORT_READY: "📊 REPORT READY",
    BATCH_PURGED: "🗑 PURGED",
}

# ── Email status ─────────────────────────────────────────────────────────
EMAIL_PENDING = "PENDING"
EMAIL_VALID = "VALID"
EMAIL_INVALID = "INVALID"

# ── User conversation state ─────────────────────────────────────────────
USER_IDLE = "USER_IDLE"
USER_SELECT_BATCH = "USER_SELECT_BATCH"
USER_WAITING_GMAIL_LIST = "USER_WAITING_GMAIL_LIST"
USER_SELECT_CHECK_BATCH = "USER_SELECT_CHECK_BATCH"

# ── Admin conversation state ─────────────────────────────────────────────
ADMIN_IDLE = "ADMIN_IDLE"
ADMIN_INPUT_DEPOSIT_DATE = "ADMIN_INPUT_DEPOSIT_DATE"
ADMIN_INPUT_ESTIMATED_REPORT = "ADMIN_INPUT_ESTIMATED_REPORT"
ADMIN_CONFIRM_BATCH = "ADMIN_CONFIRM_BATCH"
ADMIN_SELECT_BATCH_FOR_LOCK = "ADMIN_SELECT_BATCH_FOR_LOCK"
ADMIN_SELECT_BATCH_FOR_INVALID = "ADMIN_SELECT_BATCH_FOR_INVALID"
ADMIN_WAITING_INVALID_LIST = "ADMIN_WAITING_INVALID_LIST"
ADMIN_SELECT_BATCH_FOR_EXPORT = "ADMIN_SELECT_BATCH_FOR_EXPORT"
ADMIN_SELECT_BATCH_FOR_STATUS = "ADMIN_SELECT_BATCH_FOR_STATUS"
ADMIN_SELECT_BATCH_FOR_PURGE = "ADMIN_SELECT_BATCH_FOR_PURGE"
ADMIN_SELECT_USER_FOR_EXPORT = "ADMIN_SELECT_USER_FOR_EXPORT"

# States yang boleh menerima /cancel (semua state selain IDLE pada dasarnya
# bisa dibatalkan; daftar ini untuk dokumentasi/consistency check).
CANCELLABLE_STATES = frozenset(
    {
        USER_SELECT_BATCH,
        USER_WAITING_GMAIL_LIST,
        USER_SELECT_CHECK_BATCH,
        ADMIN_INPUT_DEPOSIT_DATE,
        ADMIN_INPUT_ESTIMATED_REPORT,
        ADMIN_CONFIRM_BATCH,
        ADMIN_SELECT_BATCH_FOR_LOCK,
        ADMIN_SELECT_BATCH_FOR_INVALID,
        ADMIN_WAITING_INVALID_LIST,
        ADMIN_SELECT_BATCH_FOR_EXPORT,
        ADMIN_SELECT_BATCH_FOR_STATUS,
        ADMIN_SELECT_BATCH_FOR_PURGE,
        ADMIN_SELECT_USER_FOR_EXPORT,
    }
)
