"""
Normalisasi dan validasi input daftar Gmail.

Aturan normalisasi (sesuai spesifikasi §8):
    1. Trim whitespace.
    2. Lowercase.
    3. Hapus karakter invisible / zero-width.
    4. Hapus emoji yang tidak relevan.
    5. Normalisasi line ending.
    6. Abaikan baris kosong.
    7. Validasi format email (STRICT: hanya @gmail.com).
    8. Detect duplicate dalam input yang sama.

PENTING: Normalisasi TIDAK BOLEH mengubah alamat email secara sembarangan.
    - JANGAN menghapus "." pada local-part.
    - JANGAN menghapus "+" pada local-part.
    Hanya trim, lowercase, dan pembersihan karakter tak-terlihat/emoji.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

from bot.config import ALLOWED_EMAIL_DOMAIN

# Karakter zero-width / invisible yang umum menyelip dari copy-paste
# (zero-width space, zero-width joiner/non-joiner, BOM, word joiner,
# left-to-right/right-to-left marks, dll).
_ZERO_WIDTH_CHARS = (
    "\u200b"  # zero width space
    "\u200c"  # zero width non-joiner
    "\u200d"  # zero width joiner
    "\u200e"  # left-to-right mark
    "\u200f"  # right-to-left mark
    "\ufeff"  # BOM / zero width no-break space
    "\u2060"  # word joiner
    "\u180e"  # mongolian vowel separator
)
_ZERO_WIDTH_RE = re.compile(f"[{_ZERO_WIDTH_CHARS}]")

# Regex validasi format email lokal (RFC-5322 disederhanakan, cukup ketat
# untuk kebutuhan praktis tanpa menolak email yang valid secara umum).
# local-part: huruf/angka/titik/plus/underscore/dash (tanpa titik di awal,
# akhir, atau berturutan — tapi kita longgarkan sedikit untuk kepraktisan
# karena Gmail sendiri cukup toleran; validasi domain yang paling ketat).
_EMAIL_RE = re.compile(
    r"^[a-zA-Z0-9](?:[a-zA-Z0-9._+-]*[a-zA-Z0-9])?@([a-zA-Z0-9-]+\.[a-zA-Z0-9.-]+)$"
)


def _strip_emoji(text: str) -> str:
    """Hapus karakter emoji/simbol non-teks dari string.

    Menggunakan kategori unicode: So (Symbol, other) dan Cs (Surrogate,
    dipakai emoji di beberapa encoding) dibuang. Kategori umum huruf/angka/
    tanda baca standar dipertahankan.
    """
    out_chars = []
    for ch in text:
        cat = unicodedata.category(ch)
        # Buang emoji (biasanya kategori So) dan surrogate pairs.
        if cat in ("So", "Cs"):
            continue
        # Buang juga blok emoji umum berdasarkan code point (jaga-jaga
        # untuk emoji yang lolos dari kategori unicodedata, misal beberapa
        # varian/skin-tone modifier).
        cp = ord(ch)
        if (
            0x1F300 <= cp <= 0x1FAFF  # misc symbols, emoticons, transport, dst
            or 0x2600 <= cp <= 0x27BF  # misc symbols & dingbats
            or 0xFE00 <= cp <= 0xFE0F  # variation selectors
            or 0x1F1E6 <= cp <= 0x1F1FF  # regional indicator (bendera)
        ):
            continue
        out_chars.append(ch)
    return "".join(out_chars)


def normalize_line(raw_line: str) -> str:
    """Normalisasi satu baris input menjadi kandidat email bersih.

    Tidak melakukan validasi format — hanya membersihkan representasi teks.
    """
    text = raw_line

    # Normalisasi line ending sudah ditangani oleh caller (split lines),
    # di sini kita hanya jaga-jaga ada karakter \r tersisa.
    text = text.replace("\r", "")

    # Hapus karakter invisible/zero-width.
    text = _ZERO_WIDTH_RE.sub("", text)

    # Hapus emoji.
    text = _strip_emoji(text)

    # Trim whitespace di awal/akhir (termasuk whitespace unicode aneh
    # seperti non-breaking space yang mungkin lolos).
    text = text.strip()
    text = text.strip("\u00a0\u2007\u202f")  # nbsp & varian spasi lain
    text = text.strip()

    # Lowercase.
    text = text.lower()

    return text


def is_valid_gmail(email: str) -> bool:
    """Validasi format email DAN domain harus strict @gmail.com."""
    if not email:
        return False
    if "@" not in email:
        return False
    if not _EMAIL_RE.match(email):
        return False
    domain = email.rsplit("@", 1)[-1]
    return domain == ALLOWED_EMAIL_DOMAIN


@dataclass
class ParseResult:
    """Hasil parsing satu blok input daftar gmail dari user."""

    total_input: int = 0          # total baris non-kosong yang diproses
    valid_unique: list[str] = field(default_factory=list)   # siap disimpan
    invalid_format: list[str] = field(default_factory=list)  # gagal format
    duplicate_in_submission: list[str] = field(default_factory=list)  # dobel di input yang sama


def parse_gmail_list(raw_text: str) -> ParseResult:
    """Parse teks mentah (banyak baris) menjadi daftar email yang sudah
    dinormalisasi, sekaligus memisahkan mana yang valid, invalid format,
    dan duplicate DALAM submission yang sama.

    Tidak melakukan pengecekan duplicate terhadap database — itu tanggung
    jawab layer database/models karena butuh query.
    """
    result = ParseResult()

    # Normalisasi line ending universal dulu, lalu split.
    normalized_text = raw_text.replace("\r\n", "\n").replace("\r", "\n")
    lines = normalized_text.split("\n")

    seen_in_this_submission: set[str] = set()

    for raw_line in lines:
        cleaned = normalize_line(raw_line)

        if not cleaned:
            # Baris kosong diabaikan, tidak dihitung sebagai total_input.
            continue

        result.total_input += 1

        if not is_valid_gmail(cleaned):
            result.invalid_format.append(cleaned)
            continue

        if cleaned in seen_in_this_submission:
            result.duplicate_in_submission.append(cleaned)
            continue

        seen_in_this_submission.add(cleaned)
        result.valid_unique.append(cleaned)

    return result
