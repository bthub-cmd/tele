"""
Export data batch/user ke file TXT dan Excel.

Dua jenis export dengan tujuan berbeda:
    1. Backup rekap (sebelum purge) — format PER USER dengan ringkasan
       total setor/valid/invalid + daftar emailnya. Dipakai fungsi
       export_recap_txt / export_recap_xlsx.
    2. Export data batch mentah (menu admin "Export Data") — format PER
       USER juga, tapi lebih ringkas (nama, daftar gmail, total) tanpa
       breakdown valid/invalid — karena bisa dipakai sebelum report
       matching selesai. Dipakai fungsi export_batch_raw_txt /
       export_batch_raw_xlsx.

File dibuat di direktori sementara lalu path-nya dikembalikan supaya
handler bisa mengirimkannya sebagai dokumen Telegram.
"""

from __future__ import annotations

import os
import tempfile

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from bot.models import UserRecapRow


def _autosize_columns(ws, headers: list[str], max_width: int = 60) -> None:
    for col_idx, header in enumerate(headers, start=1):
        max_len = len(header)
        for row in ws.iter_rows(min_row=2, min_col=col_idx, max_col=col_idx):
            val = row[0].value
            if val:
                longest_line = max((len(line) for line in str(val).split("\n")), default=0)
                max_len = max(max_len, longest_line)
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 2, max_width)


def _style_header(ws, headers: list[str]) -> None:
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(vertical="center")
    ws.freeze_panes = "A2"


# ═══════════════════════════════════════════════════════════════════════
# BACKUP REKAP (sebelum purge) — per user, dengan breakdown valid/invalid
# ═══════════════════════════════════════════════════════════════════════

def export_recap_txt(rows: list[UserRecapRow], filename_hint: str) -> str:
    """Format TXT rekap per user:

        @userA
        Total Setoran: 3
        Total Valid: 2
        Total Invalid: 1
        Gmail Disetor: budi@gmail.com, jajang@gmail.com, udin@gmail.com
        Gmail Invalid: budi@gmail.com

        @userB
        ...
    """
    fd, path = tempfile.mkstemp(prefix=f"{filename_hint}_", suffix=".txt")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        blocks = []
        for row in rows:
            all_str = ", ".join(row.emails_all) if row.emails_all else "-"
            invalid_str = ", ".join(row.emails_invalid) if row.emails_invalid else "-"
            block = (
                f"{row.user_label}\n"
                f"Total Setoran: {row.total_gmail}\n"
                f"Total Valid: {row.total_valid}\n"
                f"Total Invalid: {row.total_invalid}\n"
                f"Gmail Disetor: {all_str}\n"
                f"Gmail Invalid: {invalid_str}"
            )
            blocks.append(block)
        f.write("\n\n".join(blocks) + "\n")
    return path


def export_recap_xlsx(rows: list[UserRecapRow], filename_hint: str) -> str:
    """Format Excel rekap per user (1 baris = 1 user):

        Nama/Username | Total Disetor | Total Valid | Total Invalid | Email Valid | Email Invalid
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "Rekap Per User"

    headers = ["Nama/Username", "Total Disetor", "Total Valid", "Total Invalid", "Email Valid", "Email Invalid"]
    ws.append(headers)
    _style_header(ws, headers)

    for row in rows:
        ws.append(
            [
                row.user_label,
                row.total_gmail,
                row.total_valid,
                row.total_invalid,
                "\n".join(row.emails_valid) if row.emails_valid else "-",
                "\n".join(row.emails_invalid) if row.emails_invalid else "-",
            ]
        )
        last_row = ws.max_row
        for col in (5, 6):
            ws.cell(row=last_row, column=col).alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(row=last_row, column=1).alignment = Alignment(vertical="top")

    _autosize_columns(ws, headers)

    fd, path = tempfile.mkstemp(prefix=f"{filename_hint}_", suffix=".xlsx")
    os.close(fd)
    wb.save(path)
    return path


# ═══════════════════════════════════════════════════════════════════════
# EXPORT DATA BATCH MENTAH (menu admin "Export Data") — per user, ringkas
# ═══════════════════════════════════════════════════════════════════════

def export_batch_raw_txt(rows: list[UserRecapRow], filename_hint: str) -> str:
    """TXT mentah: daftar seluruh email tanpa pengelompokan (satu email
    per baris), sesuai kebutuhan raw list."""
    fd, path = tempfile.mkstemp(prefix=f"{filename_hint}_", suffix=".txt")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        for row in rows:
            for email in row.emails_all:
                f.write(email + "\n")
    return path


def export_batch_raw_xlsx(rows: list[UserRecapRow], filename_hint: str) -> str:
    """Format Excel ringkas per user (1 baris = 1 user), tanpa breakdown
    valid/invalid — cocok dipakai sebelum atau sesudah report matching:

        Nama/Username | Gmail yang Disetor | Total Gmail Disetor
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "Data Batch"

    headers = ["Nama/Username", "Gmail yang Disetor", "Total Gmail Disetor"]
    ws.append(headers)
    _style_header(ws, headers)

    for row in rows:
        ws.append(
            [
                row.user_label,
                "\n".join(row.emails_all) if row.emails_all else "-",
                row.total_gmail,
            ]
        )
        last_row = ws.max_row
        ws.cell(row=last_row, column=2).alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(row=last_row, column=1).alignment = Alignment(vertical="top")

    _autosize_columns(ws, headers)

    fd, path = tempfile.mkstemp(prefix=f"{filename_hint}_", suffix=".xlsx")
    os.close(fd)
    wb.save(path)
    return path


# ═══════════════════════════════════════════════════════════════════════
# EXPORT PER USER TUNGGAL (dari menu Export Data > Export User)
# ═══════════════════════════════════════════════════════════════════════

def export_single_user_txt(row: UserRecapRow, filename_hint: str) -> str:
    """TXT raw untuk 1 user: daftar email saja, satu per baris."""
    fd, path = tempfile.mkstemp(prefix=f"{filename_hint}_", suffix=".txt")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        for email in row.emails_all:
            f.write(email + "\n")
    return path


def export_single_user_xlsx(row: UserRecapRow, filename_hint: str) -> str:
    """Excel untuk 1 user, format sama seperti export_batch_raw_xlsx
    tapi hanya 1 baris."""
    return export_batch_raw_xlsx([row], filename_hint)
