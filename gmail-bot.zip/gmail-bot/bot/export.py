"""
Export data batch/user ke file TXT dan Excel.

File dibuat di direktori sementara lalu path-nya dikembalikan supaya
handler bisa mengirimkannya sebagai dokumen Telegram.
"""

from __future__ import annotations

import os
import tempfile

from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from bot.models import EmailExportRow


def export_emails_txt(rows: list[EmailExportRow], filename_hint: str) -> str:
    """Export raw email list (satu email per baris) ke file TXT.
    Sesuai §24: format TXT hanya berisi daftar email mentah."""
    fd, path = tempfile.mkstemp(prefix=f"{filename_hint}_", suffix=".txt")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        for row in rows:
            f.write(row.email + "\n")
    return path


def export_emails_xlsx(rows: list[EmailExportRow], filename_hint: str, title: str) -> str:
    """Export detail lengkap (No, User, Gmail, Status, Submission ID,
    Submitted At) ke file Excel. Sesuai §24."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"

    headers = ["No", "User", "Gmail", "Status", "Submission ID", "Submitted At"]
    ws.append(headers)
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font = Font(bold=True)

    for row in rows:
        ws.append(
            [
                row.no,
                row.user_label,
                row.email,
                row.status,
                row.submission_code,
                row.submitted_at,
            ]
        )

    # Lebar kolom otomatis sederhana berdasarkan konten terpanjang.
    for col_idx, header in enumerate(headers, start=1):
        max_len = len(header)
        for row in rows:
            values = [row.no, row.user_label, row.email, row.status, row.submission_code, row.submitted_at]
            val = str(values[col_idx - 1])
            max_len = max(max_len, len(val))
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 2, 40)

    fd, path = tempfile.mkstemp(prefix=f"{filename_hint}_", suffix=".xlsx")
    os.close(fd)
    wb.save(path)
    return path
