"""
Builder untuk inline keyboard (tombol) Telegram.

Dipisah dari handlers supaya UI konsisten dan mudah diubah tanpa
menyentuh logika bisnis.
"""

from __future__ import annotations

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from bot.models import Batch
from bot.states import BATCH_STATUS_LABELS


def main_user_menu() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("📥 Setor Gmail", callback_data="user:deposit")],
        [InlineKeyboardButton("📊 Cek Gmail", callback_data="user:check")],
        [InlineKeyboardButton("📋 Batch Saya", callback_data="user:mybatches")],
    ]
    return InlineKeyboardMarkup(rows)


def main_admin_menu() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("🟢 Open Batch", callback_data="admin:open")],
        [InlineKeyboardButton("🔒 Lock Batch", callback_data="admin:lock")],
        [InlineKeyboardButton("📋 Daftar Batch", callback_data="admin:list")],
        [InlineKeyboardButton("❌ Tambah Invalid Report", callback_data="admin:invalid")],
        [InlineKeyboardButton("📊 Status Confirmation", callback_data="admin:confirmstatus")],
        [InlineKeyboardButton("📦 Export Data", callback_data="admin:export")],
        [InlineKeyboardButton("🗑 Purge Batch", callback_data="admin:purge")],
        [InlineKeyboardButton("📈 Statistik", callback_data="admin:stats")],
    ]
    return InlineKeyboardMarkup(rows)


def batch_selection_keyboard(batches: list[Batch], callback_prefix: str) -> InlineKeyboardMarkup:
    """Keyboard daftar batch. callback_data format: '{prefix}:{batch_id}'"""
    rows = []
    for b in batches:
        label = f"{b.batch_code} ({BATCH_STATUS_LABELS.get(b.status, b.status)})"
        rows.append([InlineKeyboardButton(label, callback_data=f"{callback_prefix}:{b.id}")])
    rows.append([InlineKeyboardButton("❌ Batal", callback_data="cancel")])
    return InlineKeyboardMarkup(rows)


def confirm_open_batch_keyboard(batch_id: int) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("✅ OPEN BATCH", callback_data=f"admin:confirmopen:{batch_id}")],
        [InlineKeyboardButton("❌ BATAL", callback_data=f"admin:cancelopen:{batch_id}")],
    ]
    return InlineKeyboardMarkup(rows)


def export_format_keyboard(batch_id: int, scope: str, user_id: int | None = None) -> InlineKeyboardMarkup:
    """scope: 'batch' atau 'user'. Jika user, sertakan user_id di callback."""
    if scope == "batch":
        txt_cb = f"admin:exportbatchtxt:{batch_id}"
        xlsx_cb = f"admin:exportbatchxlsx:{batch_id}"
    else:
        txt_cb = f"admin:exportusertxt:{batch_id}:{user_id}"
        xlsx_cb = f"admin:exportuserxlsx:{batch_id}:{user_id}"
    rows = [
        [InlineKeyboardButton("📄 TXT", callback_data=txt_cb)],
        [InlineKeyboardButton("📊 EXCEL", callback_data=xlsx_cb)],
    ]
    return InlineKeyboardMarkup(rows)


def export_scope_keyboard() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("Export Batch", callback_data="admin:exportscope:batch")],
        [InlineKeyboardButton("Export User", callback_data="admin:exportscope:user")],
    ]
    return InlineKeyboardMarkup(rows)


def confirmation_button(batch_id: int) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton("✅ SUDAH CEK & KONFIRMASI", callback_data=f"user:confirm:{batch_id}")]]
    return InlineKeyboardMarkup(rows)


def purge_confirm_keyboard(batch_id: int, force: bool = False) -> InlineKeyboardMarkup:
    if force:
        rows = [
            [InlineKeyboardButton("⚠️ FORCE PURGE", callback_data=f"admin:forcepurge:{batch_id}")],
            [InlineKeyboardButton("BATAL", callback_data="cancel")],
        ]
    else:
        rows = [
            [InlineKeyboardButton("🗑 PURGE BATCH", callback_data=f"admin:doPurge:{batch_id}")],
            [InlineKeyboardButton("BATAL", callback_data="cancel")],
        ]
    return InlineKeyboardMarkup(rows)


def user_selection_keyboard(users: dict[int, str], batch_id: int) -> InlineKeyboardMarkup:
    """users: {user_id: label}"""
    rows = [
        [InlineKeyboardButton(label, callback_data=f"admin:selectuser:{batch_id}:{uid}")]
        for uid, label in users.items()
    ]
    rows.append([InlineKeyboardButton("❌ Batal", callback_data="cancel")])
    return InlineKeyboardMarkup(rows)
