# Telegram Gmail Validation Bot

Bot Telegram untuk mengelola setoran daftar Gmail secara temporary dan
melakukan validasi Gmail berdasarkan laporan invalid dari admin.

## 1. Arsitektur

```
gmail-bot/
├── bot/
│   ├── config.py           # Token, admin whitelist, konstanta (via env var)
│   ├── database.py         # Schema SQLite + koneksi
│   ├── models.py           # Semua query & logika bisnis inti (duplicate
│   │                       #   checking, matching, purge, dst)
│   ├── validators.py       # Normalisasi & validasi format email
│   ├── states.py           # Konstanta state machine (batch status,
│   │                       #   status email, state percakapan)
│   ├── keyboards.py        # Builder inline keyboard Telegram
│   ├── export.py           # Export ke TXT & Excel (openpyxl)
│   ├── handlers/
│   │   ├── common.py       # /start, /admin, /cancel, helper kirim
│   │   │                   #   pesan panjang (dipecah otomatis)
│   │   ├── user.py         # Semua interaksi user: setor, cek, konfirmasi
│   │   └── admin.py        # Semua interaksi admin: open/lock/invalid
│   │                       #   report/export/purge/statistik
│   └── main.py              # Registrasi handler & entry point
├── requirements.txt
└── README.md
```

Kode dipisah per tanggung jawab (SQL murni ada di `models.py`, UI di
`keyboards.py`, handler Telegram di `handlers/`) supaya mudah dirawat
dan tidak ada satu file raksasa berisi seluruh logic.

## 2. Database Schema

SQLite dengan tabel: `users`, `batches`, `submissions`, `emails`,
`confirmations`, `user_states` (state percakapan, persisted supaya
tahan restart). Lihat `bot/database.py` untuk DDL lengkap.

Poin penting:
- `UNIQUE(batch_id, email)` di tabel `emails` mencegah duplicate dalam
  batch yang sama di level database.
- Duplicate **lintas batch** dicek di application logic
  (`models.find_existing_email_batches`) dengan query `WHERE email IN (...)`
  terhadap seluruh baris `emails` yang masih ada — karena baris
  otomatis terhapus saat purge, scope duplicate checking otomatis
  benar tanpa perlu filter status tambahan.
- Index di kolom `email`, dan `(batch_id, status)` untuk mempercepat
  query matching/summary.

## 3. State Machine

- **Batch status**: `DRAFT → OPEN → LOCKED → REPORT_READY → PURGED`
- **Email status**: `PENDING → VALID` atau `PENDING → INVALID`
- **State percakapan** user/admin disimpan di tabel `user_states` per
  `telegram_user_id`, bukan in-memory — supaya kalau bot restart, user
  tidak nyangkut di flow yang aneh (mereka cukup kirim `/cancel` atau
  mulai ulang dari menu).

## 4. Duplicate Checking

1. Dalam satu submission: dideteksi di `validators.parse_gmail_list`
   (set `seen_in_this_submission`).
2. Lintas submission/user dalam batch yang sama, dan lintas batch lain
   yang belum di-purge: dideteksi di `models.save_submission` via
   `find_existing_email_batches`.
3. Setelah batch di-purge, baris di tabel `emails` untuk batch itu
   dihapus permanen — sehingga email yang sama otomatis bisa dipakai
   lagi di batch baru (Rule 6).

## 5. Lifecycle Batch

```
/open → DRAFT → (admin konfirmasi) → OPEN
                                        │  user submit gmail
                                        ▼
                                      LOCKED  (admin /lock)
                                        │  admin kirim invalid report
                                        ▼
                                  REPORT_READY
                                        │  semua user konfirmasi
                                        ▼
                                     PURGED  (admin purge / force purge)
```

Batch TIDAK terikat tanggal — satu batch bisa melewati pergantian
tanggal (Rule 2). Beberapa batch bisa OPEN bersamaan.

## 6. Permission

- **User**: hanya bisa akses data miliknya sendiri (difilter
  `user_id` di setiap query). Tidak bisa export, tidak bisa lihat
  data user lain, bahkan jika mencoba menebak `batch_id` di
  `callback_data` secara langsung.
- **Admin**: whitelist via environment variable `ADMIN_IDS`. Setiap
  handler admin memanggil `_guard_admin()` di awal — proteksi ini
  tetap dijalankan walau tombolnya cuma muncul di menu admin, untuk
  berjaga-jaga terhadap `callback_data` yang direplay/ditebak oleh
  non-admin.

## 7. Setup & Menjalankan

### Prasyarat
- Python 3.10+
- Bot token dari [@BotFather](https://t.me/BotFather)
- Telegram `user_id` kamu (bisa didapat dari bot seperti @userinfobot)

### Langkah instalasi

```bash
# 1. Masuk ke folder project
cd gmail-bot

# 2. (Opsional tapi disarankan) buat virtual environment
python3 -m venv venv
source venv/bin/activate      # Linux/Mac
# venv\Scripts\activate       # Windows

# 3. Install dependency
pip install -r requirements.txt

# 4. Set environment variable
export BOT_TOKEN="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"
export ADMIN_IDS="111111111"          # user_id Telegram admin, pisah koma jika >1
export DB_PATH="gmail_bot.db"          # opsional, default: gmail_bot.db

# 5. Jalankan bot
python -m bot.main
```

Di Windows (PowerShell), ganti langkah 4 dengan:
```powershell
$env:BOT_TOKEN="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"
$env:ADMIN_IDS="111111111"
```

### Menjalankan sebagai proses background (Linux, opsional)

```bash
nohup python -m bot.main > bot.log 2>&1 &
```

Atau gunakan `systemd`/`supervisor`/`screen`/`tmux` sesuai preferensi.

## 8. Catatan Migrasi (jika sebelumnya sudah pakai versi tanpa nama batch)

Jika kamu sebelumnya sudah menjalankan bot ini dan punya file database
lama (`gmail_bot.db`) yang dibuat sebelum kolom `batch_name` ditambahkan,
**hapus file database lama** sebelum menjalankan versi ini — skema
tabel `batches` berubah (kolom `batch_name` baru wajib diisi):

```bash
rm gmail_bot.db gmail_bot.db-wal gmail_bot.db-shm  # kalau ada
python -m bot.main
```

Bot akan otomatis membuat database baru dengan skema terbaru saat
pertama kali dijalankan. Semua batch lama yang belum di-purge akan
hilang — pastikan sudah export/backup data penting terlebih dahulu
kalau ada batch aktif di database lama.

## 9. Fitur yang Sudah Diimplementasikan

- ✅ Open batch dengan 3 pertanyaan berurutan: **nama batch** (bebas,
  ditampilkan ke semua orang), tanggal setoran, perkiraan report.
  ID internal (`BATCH-001`, dst) tetap ada di database tapi **tidak
  pernah ditampilkan** — hanya nama batch yang muncul di semua pesan.
  Kalau ada 2 batch aktif dengan nama sama persis, bot otomatis
  menambahkan `(2)`, `(3)`, dst di belakang nama supaya tetap bisa
  dibedakan.
- ✅ **Konfirmasi sebelum lock**: admin pilih batch → bot tampilkan
  ringkasan (jumlah user, jumlah gmail) → admin konfirmasi → baru
  benar-benar terkunci. Tidak ada aksi tidak sengaja.
- ✅ User submit gmail berkali-kali per batch, duplicate ditolak per-baris
- ✅ Normalisasi email (trim, lowercase, hapus zero-width/emoji) tanpa
  mengubah titik/plus pada local-part
- ✅ Validasi ketat: hanya domain `@gmail.com` yang diterima
- ✅ Duplicate checking dalam-submission, dalam-batch, dan lintas-batch
  (selama data lama belum di-purge)
- ✅ Invalid report matching berbasis `batch_id + email` (bukan
  pencarian global)
- ✅ Email invalid yang tidak ditemukan di batch dilaporkan sekali ke
  admin, tidak disimpan permanen
- ✅ User hanya melihat hasil via Telegram (pesan panjang otomatis
  dipecah beberapa bagian)
- ✅ Konfirmasi hasil oleh user, tracking siapa yang belum konfirmasi
- ✅ **Export data batch** (menu Export Data): format Excel/TXT rapi
  **per user** — 1 baris = 1 user dengan kolom Nama, Gmail yang
  Disetor (digabung dalam 1 sel), Total Gmail Disetor. Tidak ada lagi
  1 baris per email yang bikin sheet panjang.
- ✅ Purge normal (butuh semua user confirm) & force purge (dengan
  konfirmasi kedua)
- ✅ **Backup rekap otomatis** (TXT + Excel) dikirim ke admin sebelum
  data di-purge — format per user: Nama, Total Disetor, Total Valid,
  Total Invalid, Email Valid, Email Invalid (semua email milik 1 user
  dirangkum dalam 1 baris, bukan tersebar banyak baris)
- ✅ **Reminder on-demand**: saat admin membuka `/admin`, bot
  menampilkan batch yang masih LOCKED (menunggu report) atau
  REPORT_READY (menunggu konfirmasi user)
- ✅ `/cancel` di semua flow yang sedang menunggu input
- ✅ Semua callback memverifikasi role (admin/user) di server-side,
  tidak percaya `callback_data` mentah dari client
- ✅ State percakapan persisted ke database (tahan restart bot)
- ✅ **Log VPS lebih rapi**: noise dari library pihak ketiga (`httpx`,
  `httpcore` yang mencatat setiap HTTP request polling ke Telegram)
  diredam ke level WARNING — log yang tampil di terminal/journalctl
  hanya event penting bot (startup, error), bukan setiap detik
  `getUpdates`.

## 9. Asumsi & Keputusan Implementasi

Sesuai instruksi spesifikasi §41, berikut asumsi yang diambil untuk
bagian yang tidak didetailkan secara eksplisit:

- **Format tanggal** (`deposit_date`, `estimated_report_date`) disimpan
  sebagai teks bebas persis seperti yang diketik admin (tidak
  di-parse ke objek `date`), karena spesifikasi hanya memberi contoh
  format "18 September 2026" tanpa aturan parsing yang ketat. Ini
  paling sederhana dan aman — tidak ada risiko salah parse.
- **`submission_code`** dan tidak ada kolom `id` yang diekspos ke
  user — memakai kode acak 6 karakter (`SUB-XXXXXX`) supaya tidak
  predictable, sesuai security rule no.10 (jangan percaya parameter
  yang bisa ditebak).
- **Tidak ada job scheduler/background**, sesuai keputusan reminder
  on-demand — semua reminder dicek saat admin membuka `/admin`, bukan
  dikirim otomatis oleh proses terpisah.
- **Tidak ada audit log** aksi admin, sesuai keputusan eksplisit
  (skala 1 admin).
- **WAL mode SQLite** diaktifkan untuk sedikit lebih toleran terhadap
  akses bersamaan (walau dengan 1 admin, risiko konflik minim; ini
  murni best-practice tambahan).

## 10. Pengujian yang Sudah Dilakukan

Karena lingkungan pengembangan ini tidak memiliki akses internet
untuk mengunduh `python-telegram-bot` maupun untuk menjalankan bot
secara live terhadap Telegram API sungguhan, verifikasi dilakukan
dengan:

1. **Compile check** (`py_compile`) di semua file — tidak ada syntax
   error.
2. **Unit test fungsional** untuk `validators.py` (normalisasi,
   validasi domain, parsing multi-baris) dan `models.py` (duplicate
   checking dalam & lintas batch, matching, purge, reusability
   setelah purge) — dijalankan langsung terhadap SQLite asli.
3. **Test fungsional `export.py`** — file TXT & Excel benar-benar
   dibuat dan dibaca ulang untuk verifikasi isi.
4. **Simulasi end-to-end** seluruh alur (`/start` → admin buka batch →
   user submit multi-kali → lock → invalid report → user cek &
   konfirmasi → reminder → backup sebelum purge → purge → verifikasi
   data terhapus) menggunakan mock objek Telegram, memverifikasi
   tidak ada exception di sepanjang alur asli kode (bukan stub-nya).
5. **Test keamanan**: memverifikasi non-admin diblokir dari seluruh
   endpoint admin (termasuk saat mencoba mengirim `callback_data`
   admin secara langsung), dan user tidak bisa melihat data user lain
   walau mencoba menebak `batch_id` orang lain.

**Yang belum bisa diverifikasi di lingkungan ini** (karena butuh
token Telegram asli & koneksi internet) adalah interaksi langsung
dengan Telegram Bot API — formatting pesan di client Telegram
sungguhan, perilaku `send_document` dengan file besar, dan rate
limit sungguhan. Disarankan melakukan uji coba manual singkat dengan
bot token asli di grup/chat pribadi sebelum dipakai untuk operasional
penuh.

## 11. Batasan yang Disengaja (sesuai diskusi)

- Skala target: <2.000 email/hari — tidak ada optimisasi performa
  khusus di luar indexing dasar.
- Hanya 1 admin — tidak ada locking khusus untuk race condition antar
  admin.
- Tidak ada audit log.
- Domain email strict `@gmail.com` — semua domain lain (termasuk
  `googlemail.com`) ditolak sebagai format invalid.
